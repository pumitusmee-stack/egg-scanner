loadstring(game:HttpGet("https://raw.githubusercontent.com/USERNAME/REPO/BRANCH/egg_scanner_enhanced.lua"))()
