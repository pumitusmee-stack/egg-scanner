--!
--  STEAL AN EGG :: AUTO FARM  (full source)
--  place 107778070777162
--
--  วงจร:  ขโมยไข่จากโซน -> วิ่งกลับฐาน -> วางไข่ -> ฟัก -> วางเป็ต
--         -> ขายตัวที่ทำเงินน้อย -> วิ่งลู่เพิ่ม Speed -> วนใหม่
--
--    steal   = fireproximityprompt(prompt "CarryAreaEgg")  ระยะ 8 studs
--    claim   = เดิน/วาร์ปเข้าเขต PetArea ของ plot ตัวเอง -> ได้ Tool ไข่
--    place   = Eggs: RequestPlaceEgg { Uid, LocalCFrame }   (local ของ CenterPoint)
--    hatch   = Eggs: RequestHatchEgg(uid) -> RequestCompleteHatchEgg(uid)
--    equip   = ActiveAssets: RequestEquip(uid)
--    sell    = ActiveAssets: RequestSell(uid)
--    speed   = ยืนบน plot.TreadmillBottom  (+20 Speed/วิ ต่อ multiplier ลู่)
--
--  สูตรรายได้ (ตรวจแล้ว error 0.00% กับเป็ต 13 ตัว):
--    MoneyPerSecond = EarningRate(หมวด) * Scale^1.85 * ตัวคูณ Mutation
--
--  วิธีใช้ (1 คลิกจบ):
--    โหลดไฟล์นี้เฉยๆ ก็วิ่งเลย - default คือพรีเซ็ต "balanced" + AutoStart
--    อยากปรับ: ตั้ง _G.EggConfig = { ... } ก่อน แล้วค่อยโหลดไฟล์นี้
--    หรือใช้ egg_run.lua ที่เตรียมไว้ให้แล้ว (ไฟล์เดียว กด Execute จบ)
--
--    ปุ่มบนแผง:  PAUSE/START  ·  MODE (สลับโหมดเดิน)  ·  STOP    (ลากแผงย้ายที่ได้)
--    คีย์ลัด:    F2 = หยุด/เล่นต่อ · F3 = สลับโหมดเดิน · F4 = ซ่อน/โชว์แผง
--
--    _G.EggStart()          = เริ่ม/เล่นต่อ
--    _G.EggPause()          = สลับสถานะหยุดชั่วคราว
--    _G.EggMode("walk")     = เปลี่ยนโหมดเดินสดๆ (ไม่ใส่ = วนไปตัวถัดไป)
--    _G.EggSet{ ChainGrab = 8 }  = แก้ config ตอนรันอยู่
--    _G.EggGoTo(Vector3)    = สั่งเดินไปจุดหนึ่งด้วย mover เดียวกับที่ฟาร์มใช้
--    _G.EggRelease()        = คืนสเตตัสตัวละครทันที (เผื่อค้างแล้วเดินไม่ได้)
--    _G.EggStop()           = ปิดสคริปต์
--
--  โหมดเดิน (CFG.MoveMode):
--    "humtween" <<< default - tween CFrame + สลับ Humanoid เป็นตัวโคลนสดๆ
--                  ไม่ anchor เลย (anchor คือสาเหตุที่โหมด tween เก่าโดน BAC เตะ)
--                  ทิ้ง Humanoid ตัวเก่า = ตัดคอนเนกชัน/สถานะที่ตัวจับเกาะอยู่
--                  WalkSpeed = 0 ระหว่างเลื่อน + ล้าง Assembly velocity ทุกช่วง
--    "walk"      - เดินจริงด้วย MoveTo  ปลอดภัยสุด ช้าสุด (= MoveFallback)
--    "tween"     - แบบ anchor ของเดิม  **โดน BAC เตะมาแล้ว (Error 267)**
--    "warp"      - กระโดดตำแหน่ง  **ฆ่าทิ้ง (Health = -1000)**  อย่าใช้
--    โดนดีดกลับ/ตายเมื่อไหร่ สคริปต์ลดความเร็วเองแล้วตกไป MoveFallback ให้อัตโนมัติ
--
--  ข้อควรระวังของเกมนี้ (เจอมากับตัวตอนทดสอบ):
--    * ห้าม "กระโดดตำแหน่ง" (เซ็ต hrp.CFrame ทีละไกลๆ) เด็ดขาด
--      ทดสอบแล้วทุกแบบ: ดีดกลับฐานก่อน แล้วฆ่าทิ้ง (Health = -1000)
--      แม้จะหรี่ให้เท่า WalkSpeed เป๊ะๆ ก็ยังตาย เพราะมันจับ "ตำแหน่งกระโดด"
--      ดัน AssemblyLinearVelocity เกิน ~2 เท่า ก็โดนฆ่าเหมือนกัน
--      -> สคริปต์เลยใช้ tween เลื่อนต่อเนื่องทีละช่วงสั้นๆ เกาะพื้น
--         ความเร็วผูกกับ WalkSpeed จริง (TweenSpeedMul) ไม่ใช่การโกงความเร็ว
--    * ต้องปิด ControlModule ก่อนสั่ง MoveTo ไม่งั้นมันยิง Move(0,0,0)
--      ทับทุกเฟรม เดินได้แค่ ~4 studs/s แทนที่จะเป็น 142
--    * ตายแล้ว "ไม่เกิดใหม่" - ต้องออกแล้วเข้าเกมใหม่เท่านั้น
--    * รอบรีเซ็ตโซน (กลางวัน/กลางคืน) จะย้ายเซิร์ฟทุกไม่กี่นาที = VM โดนล้าง
--      อยากให้รันต่อเอง ต้องตั้ง SourceUrl แล้วเปิด SurviveTeleport
--=====================================================================

--=====================================================================
local DEFAULTS = {
    ----------------------------------------------------------------
    -- โซนที่จะไปขโมย
    ----------------------------------------------------------------
    -- "ALL"          = ทุกโซนที่วิ่งหนีทันตาม Speed ปัจจุบัน
    -- "Forest"       = เจาะโซนเดียว
    -- {"Forest","Lake"} = เลือกหลายโซน
    --
    -- ชื่อโซนทั้งหมด (เรียงตามความเร็ว guard จากน้อยไปมาก):
    --   Forest 16 · Lake 35 · Desert 62 · Jungle 82 · Snow 98
    --   Volcano 113 · Abyss Ocean 130 · Prehistoric 152 · Cosmic 200
    --   Cherry Blossom 222 · Titan Temple 229.5   <- โซนใหม่ของ v447
    Area = "ALL",

    -- true  = ไม่เข้าโซนที่ guard เร็วกว่าเรา (ปลอดภัย - แนะนำ)
    -- โซนเรียงเป็นเส้นตรงตามแกน X จากง่ายไปยาก (Forest 600 -> Cherry Blossom 3928)
    -- จะไปโซนไกล = ต้องวิ่งผ่านทุกโซนก่อนหน้า  guard ที่เร็วกว่าเราจะไล่ทัน
    -- เพราะโซนเรียงตามความเร็ว guard พอดี "โซนปลายทางปลอดภัย" = "ทางไปก็ปลอดภัย"
    RespectGuardSpeed = true,
    -- ต้องมีความเร็ว >= guard * ค่านี้ ถึงจะกล้าเข้าโซนนั้น
    -- 0.85 = ยอมเข้าแม้ช้ากว่า guard นิดหน่อย (guard หลับอยู่ ตื่นช้า พอมีเวลาหนี)
    -- โซนง่ายสุด (Forest) เข้าได้เสมอ ไม่ว่าจะช้าแค่ไหน - บัญชีใหม่ต้องเริ่มตรงนี้
    SpeedSafety = 0.85,

    ----------------------------------------------------------------
    -- การเคลื่อนที่
    ----------------------------------------------------------------
    -- "walk"  = เดินจริงด้วย MoveTo  ไม่แตะ CFrame/Anchor  <<< default ปลอดภัยสุด
    --           เป็น API ปกติ เซิร์ฟไม่จับ รันยาวได้ไม่โดนเตะ
    -- "tween" = anchor + เขียน CFrame ทุกเฟรม  **โดน BAC เตะมาแล้ว (Error 267)**
    -- "warp"  = กระโดดตำแหน่ง  **ฆ่าทิ้ง (Health = -1000)**
    -- เร็วขึ้นแบบไม่โดนจับ = ปั้ม Speed บนลู่ให้ WalkSpeed สูงขึ้น
    -- "humtween" = tween CFrame ต่อเนื่อง + สลับ Humanoid เป็นตัวโคลนสดๆ  <<< default ใหม่
    --              ไม่ anchor ตัวเลย (anchor คือสิ่งที่ทำให้โหมด tween เก่าโดน BAC เตะ)
    --              โคลน Humanoid ใหม่แล้วทิ้งตัวเก่า = ตัดคอนเนกชัน/สถานะที่ตัวตรวจจับเกาะอยู่
    --              WalkSpeed = 0 ระหว่างเลื่อน + ล้าง Assembly velocity ทุกช่วง
    MoveMode = "humtween",
    -- โดนจับ/โดนดีด/ตาย เมื่อไหร่ ให้ตกมาใช้โหมดนี้แทนถาวร
    MoveFallback = "walk",
    MoveTimeout = 60,           -- ไปที่หมายนานสุดกี่วิ ก่อนยอมแพ้
    ArriveTol = 5,              -- ถือว่าถึงแล้วเมื่อเหลือกี่ studs
    Pathfind = true,            -- ชนกำแพงแล้วให้คำนวณทางอ้อมอัตโนมัติ (โหมด walk)
    WarpSettle = 0.35,          -- นิ่งรอหลังถึงที่หมาย ก่อนกดปุ่ม

    -- ตั้งค่าโหมด tween
    TweenStep = 12,             -- ความยาวต่อช่วง (สั้น = เกาะพื้นดีกว่า)

    -- คูณจาก WalkSpeed จริง  วัดมาแล้วกับเซิร์ฟ (บัญชีใหม่ walk 16):
    --   1x = 396 studs ไม่โดนดีดเลย รอด
    --   2x = 756 studs ไม่โดนดีดเลย รอด   <- เพดานที่ยังปลอดภัย
    --   3x = ตายใน 4 วินาที                <- อย่าเกินนี้
    -- default 1.5 เผื่อ margin ไว้ (ping สวิงได้)
    TweenSpeedMul = 1.5,
    TweenMaxSpeed = 0,          -- เพดานความเร็วสัมบูรณ์ studs/s  0 = ไม่จำกัด
                                -- ถ้า WalkSpeed สูงมากแล้วโดนฆ่า ให้ใส่เลขไว้กันเอง
    TweenClimb = 6,             -- ไต่ขึ้น/ลงได้ไม่เกินกี่ studs ต่อช่วง
    TweenRollbackLimit = 3,     -- โดนดีดกลับติดกันกี่ครั้งแล้วตัดไปโหมด walk

    -- ตั้งค่าโหมด humtween (โหมด default)
    -- ความเร็ว studs/s:  0 = คิดจาก WalkSpeed จริง * HumTweenSpeedMul (ปลอดภัย ผูกกับสเตตัสจริง)
    --                    ใส่เลขตรงๆ เช่น 450 = บังคับเร็วคงที่ (แรงกว่า เสี่ยงกว่า)
    HumTweenSpeed = 0,
    HumTweenSpeedMul = 2.0,     -- คูณจาก WalkSpeed จริง (2x = เพดานที่วัดแล้วยังรอดในเกมนี้)
    HumTweenMaxSpeed = 0,       -- เพดานสัมบูรณ์ studs/s  0 = ไม่จำกัด
    HumTweenStep = 18,          -- ความยาวต่อช่วง (ยาวกว่าโหมด tween เก่าได้ เพราะไม่ anchor)
    HumTweenClimb = 8,          -- ไต่ขึ้น/ลงได้ไม่เกินกี่ studs ต่อช่วง
    HumTweenGround = true,      -- ยิง ray เกาะพื้นทุกช่วง (ปิด = บินตรงไปเลย เสี่ยงกว่า)
    HumTweenHover = 3.2,        -- ลอยเหนือพื้นกี่ studs
    HumTweenRecloneEvery = 0,   -- โคลน Humanoid ใหม่ทุกๆ กี่ช่วง (0 = โคลนครั้งเดียวต่อ 1 การเดินทาง)
    HumTweenRollbackLimit = 3,  -- โดนดีดกลับติดกันกี่ครั้งแล้วตัดไป MoveFallback

    -- ใช้เฉพาะ MoveMode = "warp"
    Step = 50,
    Gap = 0.07,
    GroundSnap = true,
    HopTimeout = 300,

    ----------------------------------------------------------------
    -- รอบการขโมย
    ----------------------------------------------------------------
    ----------------------------------------------------------------
    -- จุดกลาง (แวะก่อนออกไปเก็บไข่ทุกครั้ง)
    ----------------------------------------------------------------
    -- ออกจากฐานแล้วพุ่งตรงไปหาไข่เลย เส้นทางจะตัดเฉียงข้ามพื้นที่
    -- ทำให้ tween ไปเกยสิ่งกีดขวาง/เข้าเขต guard เร็วเกินจำเป็น
    -- แวะจุดกลางก่อนแล้วค่อยพุ่งเข้าไข่ = เส้นทางเดิมทุกรอบ คาดเดาได้
    -- ใส่ Vector3 หรือ {x, y, z} ก็ได้ · false = ปิด (พุ่งตรงแบบเดิม)
    MidPoint = { 547, 71, -362 },
    MidPointTol = 12,           -- ใกล้จุดกลางกว่านี้แล้วถือว่าถึง ไม่ต้องแวะซ้ำ
    MidPointHome = false,       -- true = ขากลับฐานก็แวะจุดกลางด้วย

    -- true  = ขโมยด้วย remote ตัวเดียวกับที่ปุ่มในเกมเรียก (เร็วกว่า ไม่ต้องรอ hold 1.2 วิ)
    -- false = กดปุ่ม ProximityPrompt แบบเดิมอย่างเดียว
    -- ยังไงก็ยังเดินไปหาไข่ก่อนอยู่ดี เพราะเซิร์ฟน่าจะเช็กระยะ
    StealViaRemote = true,

    ChainGrab = 5,              -- ขโมยกี่ฟองต่อ 1 รอบ ก่อนกลับไปทำงานที่ฐาน
    GrabTimeout = 6,            -- รอสถานะ "กำลังถือ" นานสุดกี่วิ
    ClaimTimeout = 14,           -- รอสถานะ "ส่งเข้าฐานแล้ว" นานสุดกี่วิ
    LoopDelay = 0.5,            -- พักระหว่างรอบ
    RetryGrab = 2,              -- กดปุ่มขโมยซ้ำได้กี่ครั้งถ้าพลาด

    ----------------------------------------------------------------
    -- งานที่ฐาน
    ----------------------------------------------------------------
    AutoStart = true,
    AutoPlace = true,           -- วางไข่ที่ขโมยมาลงคอก
    AutoHatch = true,           -- ฟักไข่ที่ครบเวลา
    AutoEquip = true,           -- เอาเป็ตที่ฟักได้ลงคอก
    AutoSell = true,            -- ขายตัวที่ทำเงินน้อยเมื่อคอกเต็ม
    AutoClaimOffline = true,    -- เก็บเงิน offline ตอนเข้าเกม
    TendEvery = 3,              -- ทำงานที่ฐานทุกๆ กี่รอบขโมย

    ----------------------------------------------------------------
    -- อัปเกรด (ใช้เงินจริง)
    ----------------------------------------------------------------
    AutoUpgrade = true,         -- สวิตช์ใหญ่ของการอัปเกรดทั้งหมด
    UpgradeEvery = 5,           -- ลองอัปเกรดทุกๆ กี่รอบ

    -- อัปลู่วิ่ง = ได้ Speed เร็วขึ้น = เข้าโซนดีๆ ได้ (คุ้มที่สุด)
    -- Lv1 x2 · Lv2 x5 · Lv3 x12 · Lv4 x30 · Lv5 x80 · Lv6 x100
    -- Lv7 $75B x200 · Lv8 $2T x500 · Lv9 $50T x1000 · Lv10 $1000T x2000
    UpgradeTreadmill = true,
    MaxTreadmillPrice = 0,      -- เพดานราคาต่อครั้ง  0 = ไม่จำกัด (มีเงินเท่าไหร่อัปเท่านั้น)

    -- อัปคอก = วางเป็ตได้มากขึ้น  แพงมาก เลยปิดไว้
    UpgradePen = false,
    MaxPenPrice = 0,

    ----------------------------------------------------------------
    -- นโยบายขาย
    ----------------------------------------------------------------
    -- ห้ามขายสัตว์ที่ทำเงินตั้งแต่เท่านี้ขึ้นไป
    --   ใส่ตัวย่อได้: "10M" · "20b" · "9.9t" · 10000000 · "1,500,000"
    --   k = พัน · m = ล้าน · b = พันล้าน · t = ล้านล้าน · q = พันล้านล้าน
    --   0 = ไม่สนราคา ขายตามอันดับล้วนๆ (ตัวที่ทำเงินน้อยสุดโดนขายก่อน)
    KeepAbove = 0,
    KeepExtra = 0,              -- เว้นช่องว่างในคอกไว้กี่ช่อง
    SellBackpack = true,        -- ขายเป็ตในกระเป๋าที่แย่กว่าตัวท้ายคอกด้วย

    -- ไข่ที่ทำเงินต่ำกว่านี้ไม่ต้องออกไปเก็บ  เขียนแบบเดียวกับ KeepAbove
    -- 0 = คิดให้เอง (1% ของตัวที่ดีที่สุดที่มีอยู่)
    MinEggRate = 0,

    -- true  = เก็บ "ตัวที่ทำเงินมากสุดก่อน" เสมอ แม้จะอยู่ไกลกว่า  <<< default
    -- false = เก็บตัวที่ใกล้ที่สุดก่อน (รอบไวขึ้น แต่ได้ของถูกๆ)
    PreferBest = true,

    ----------------------------------------------------------------
    -- ลู่วิ่ง (Speed)
    ----------------------------------------------------------------
    RideTreadmill = true,       -- ขึ้นลู่เมื่อ Speed ไม่พอเข้าโซนถัดไป
    TreadmillSeconds = 20,      -- ขึ้นลู่ครั้งละกี่วิ

    -- ต้องวิ่งเร็วกว่า guard โซนแรกกี่เท่า ถึงจะเริ่มออกไปขโมย
    -- บัญชีใหม่ walk 16 = เท่า guard Forest พอดี ออกไปตอนนี้โดนจับตายแน่
    -- 1.15 = ขอเร็วกว่า 15% ก่อน (ปั้มบนลู่ไม่กี่วิก็ถึงแล้ว)
    MinSpeedToSteal = 1.15,

    -- true = เก็บไข่มาก่อนเสมอถ้ามีไข่ในโซนที่เข้าได้  (เน้นเก็บไข่)
    --        จะขึ้นลู่ปั้ม Speed เฉพาะตอนไม่มีไข่ให้เก็บเท่านั้น
    -- โซนง่ายสุด (Forest) เข้าได้เสมอ เพราะ guard เริ่มหลับ+ตื่นช้า มีจังหวะคว้า
    CollectFirst = true,
    TreadmillEvery = 10,        -- ขึ้นลู่ทุกๆ กี่รอบ (0 = เฉพาะตอน Speed ไม่พอ)
    SpeedTarget = 0,            -- ปั้ม Speed ถึงเท่านี้แล้วหยุดขึ้นลู่ (0 = อัตโนมัติ)

    ----------------------------------------------------------------
    -- รอบรีเซ็ตโซน (กลางคืน / กำแพงปิด)
    ----------------------------------------------------------------
    HandleReset = true,         -- ได้ยินสัญญาณนับถอยหลังแล้วถอยกลับฐาน
    ResetHoldFor = 8,           -- ถอยกลับฐานแล้วรอกี่วิ
    ResetWaitMax = 90,          -- รอไข่เกิดใหม่นานสุดกี่วิ

    ----------------------------------------------------------------
    -- อื่นๆ
    ----------------------------------------------------------------
    ----------------------------------------------------------------
    -- พรีเซ็ต 1 คลิก  (ทับ DEFAULTS แต่ยังโดน _G.EggConfig ทับอีกที)
    ----------------------------------------------------------------
    -- "safe"     = เดินจริงล้วน ไม่แตะ CFrame เลย  ช้าสุด ปลอดภัยสุด
    -- "balanced" = humtween 2x + ทุกอย่างอัตโนมัติ            <<< default
    -- "fast"     = humtween แรง (450 studs/s คงที่) เก็บทีละ 8 ฟอง  เสี่ยงโดนเตะ
    -- nil        = ไม่ใช้พรีเซ็ต ใช้ค่าในไฟล์ตรงๆ
    Preset = "balanced",

    ShowUI = true,              -- แผงสถานะ (อยู่กลางจอ)
    UIButtons = true,           -- ปุ่มกด Pause / Mode / Stop บนแผง (คลิกได้เลย ไม่ต้องพิมพ์)
    UIDraggable = true,         -- ลากแผงย้ายที่ได้
    UIPosX = 0.5,               -- 0 = ซ้ายสุด · 0.5 = กลาง · 1 = ขวาสุด
    UIPosY = 0.5,               -- 0 = บนสุด · 0.5 = กลาง · 1 = ล่างสุด
    StatusTextSize = 15,
    Verbose = true,             -- log ลง console
    AntiAFK = true,
    AntiKick = true,            -- ดัก Kick ฝั่ง client (กัน server BAC ไม่ได้ - ใช้ walk แทน)
    PerfMode = false,           -- ลดกราฟิก
    FpsBoost = false,           -- setfpscap
    FpsCap = 30,
    SurviveTeleport = true,     -- รันต่อเองหลังโดนย้ายเซิร์ฟ (ต้องตั้ง SourceUrl)
    SourceUrl = nil,            -- เช่น "https://raw.githubusercontent.com/.../steal_an_egg.lua"
}

local PRESETS = {
    safe = {
        MoveMode = "walk", MoveFallback = "walk",
        ChainGrab = 3, RespectGuardSpeed = true, SpeedSafety = 1.0,
    },
    balanced = {
        MoveMode = "humtween", MoveFallback = "walk",
        HumTweenSpeed = 0, HumTweenSpeedMul = 2.0, HumTweenStep = 18,
        ChainGrab = 5, RespectGuardSpeed = true, SpeedSafety = 0.85,
    },
    fast = {
        MoveMode = "humtween", MoveFallback = "humtween",
        HumTweenSpeed = 450, HumTweenStep = 28, HumTweenClimb = 14,
        ChainGrab = 8, RespectGuardSpeed = true, SpeedSafety = 0.7,
    },
}

local CFG = {}
for k, v in pairs(DEFAULTS) do CFG[k] = v end
-- ลำดับการทับ:  DEFAULTS  ->  PRESETS[Preset]  ->  _G.EggConfig (ผู้ใช้ชนะเสมอ)
do
    local want = (_G.EggConfig and _G.EggConfig.Preset) or DEFAULTS.Preset
    local pre = want and PRESETS[tostring(want):lower()]
    if pre then for k, v in pairs(pre) do CFG[k] = v end end
    CFG.Preset = want
end
for k, v in pairs(_G.EggConfig or {}) do CFG[k] = v end
_G.EggConfig = CFG

--=====================================================================
--  SERVICES / STATE
--=====================================================================
local Players           = game:GetService("Players")
local RunService        = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Lighting          = game:GetService("Lighting")
local TweenService      = game:GetService("TweenService")
local StarterGui        = game:GetService("StarterGui")

local LP = Players.LocalPlayer

-- ปิดตัวเก่าถ้ารันซ้ำ
if _G.__EGG_RUNNING then
    pcall(function() _G.EggStop() end)
    task.wait(0.4)
end
_G.__EGG_RUNNING = true

-- S = state ทั้งหมด (รวมเป็นตารางเดียว กัน local เกิน 200 ตัวใน chunk หลัก)
local S = {
    alive      = true,
    paused     = not CFG.AutoStart,
    conns      = {},
    threads    = {},
    status     = "starting",
    loops      = 0,
    stolen     = 0,
    hatched    = 0,
    sold       = 0,
    placed     = 0,
    failed     = 0,
    upgrades   = 0,
    lastUpgrade = -99,
    tiers      = nil,
    easiestGuard = nil,
    startClock = os.clock(),
    carrying   = nil,          -- record ของไข่ที่ถืออยู่
    carryMul   = 1,
    resetting  = false,
    resetUntil = 0,
    lastTread  = 0,
    plot       = nil,
    pen        = nil,
    origin     = nil,
    tread      = nil,
    ui         = nil,
    controlsObj  = nil,
    controlsHeld = false,
    -- humtween: เก็บสเตตัสจริงของ Humanoid ตัวเดิมไว้ก่อนโดนโคลนทับ
    humLocked  = false,        -- ตอนนี้ WalkSpeed โดนกดเป็น 0 อยู่ไหม
    humCache   = nil,          -- { Character = c, WalkSpeed = .., JumpPower = .., ... }
    realWalk   = nil,          -- WalkSpeed จริง (UI/การตัดสินใจต้องอ่านค่านี้ ไม่ใช่ 0)
    humTween   = nil,          -- Tween ที่กำลังเล่นอยู่
    netRoot    = nil,          -- ที่เก็บ remote (Packages.Networking)
    netCache   = nil,          -- ชื่อเก่า -> instance
}

local function track(c) S.conns[#S.conns + 1] = c return c end
local function spawnLoop(fn)
    local t = task.spawn(function()
        while S.alive do
            local ok, err = pcall(fn)
            if not ok and CFG.Verbose then warn("[Egg] loop error: " .. tostring(err)) end
            task.wait(0.2)
        end
    end)
    S.threads[#S.threads + 1] = t
    return t
end

local function log(...)
    if not CFG.Verbose then return end
    local parts = {}
    for _, v in ipairs({ ... }) do parts[#parts + 1] = tostring(v) end
    print("[Egg] " .. table.concat(parts, " "))
end

--=====================================================================
--  UTIL
--=====================================================================
local U = {}

-- "10M" / "1,500,000" / 1e7  ->  number
function U.parseAmount(v)
    if type(v) == "number" then return v end
    if type(v) ~= "string" then return 0 end
    local s = v:gsub(",", ""):gsub("%s", "")
    local num, suf = s:match("^([%d%.]+)([%a]*)$")
    if not num then return tonumber(s) or 0 end
    local mult = ({
        k = 1e3, m = 1e6, b = 1e9, t = 1e12, q = 1e15,
        qa = 1e15, qi = 1e18, s = 1e21,
    })[suf:lower()] or 1
    return (tonumber(num) or 0) * mult
end

function U.short(n)
    n = tonumber(n) or 0
    local units = { { 1e15, "Q" }, { 1e12, "T" }, { 1e9, "B" }, { 1e6, "M" }, { 1e3, "K" } }
    for _, u in ipairs(units) do
        if n >= u[1] then return string.format("%.2f%s", n / u[1], u[2]) end
    end
    return string.format("%.0f", n)
end

function U.now() return os.clock() end

-- เรียก RemoteFunction โดยไม่ให้ค้างถาวร
--=====================================================================
--  NETWORK LAYER
--  อัปเดต 2026-08-31 (PlaceVersion 447): เกมเปลี่ยนชื่อใหม่ยกชุด
--    * ReplicatedStorage.Network  ->  ReplicatedStorage.Packages.Networking
--      (ตัวใหม่เป็น ModuleScript ไม่ใช่ Folder แต่ FindFirstChild ใช้ได้เหมือนเดิม)
--    * ชื่อ remote เปลี่ยนจาก "Category: RequestThing"
--      เป็น "RF/Category/Action" (RemoteFunction) และ "RE/Category/Action" (RemoteEvent)
--    * หมวดโดนเปลี่ยนชื่อ: Plots->Homestead · Eggs->EggWorld
--      ActiveAssets->PenRoster · OfflineAssets->AwayEarnings · ClientCharacter->RigSync
--    * 2 ตัวเปลี่ยนชนิดจาก RemoteFunction เป็น RemoteEvent (ไม่มีค่าตอบกลับแล้ว)
--      -> U.invoke/U.fire เลยรับได้ทั้งสองชนิด ไม่ต้องแก้ที่เรียกใช้
--
--  โค้ดที่เหลือยังเรียกด้วย "ชื่อเก่า" เหมือนเดิม แล้วให้ตารางนี้แปลงให้
--  ถ้าเกมย้อนกลับ (หรือเซิร์ฟเก่า) ตัว resolver จะหาแบบเดิมให้เองด้วย
--=====================================================================
local NET = {
    ["Plots: RequestState"]                  = "RF/Homestead/AskState",
    ["Plots: RequestBaseUpgrade"]            = "RE/Homestead/AskBaseTierRaise",
    ["Eggs: RequestAreaEggSnapshot"]         = "RF/EggWorld/AskFieldEggSnapshot",
    ["Eggs: RequestRuntimeSnapshot"]         = "RF/EggWorld/AskLiveSnapshot",
    ["Eggs: RequestAreaEggCarry"]            = "RF/EggWorld/AskFieldEggCarry",
    ["Eggs: RequestPlaceEgg"]                = "RF/EggWorld/AskPlaceEgg",
    ["Eggs: RequestHatchEgg"]                = "RF/EggWorld/AskHatch",
    ["Eggs: RequestCompleteHatchEgg"]        = "RF/EggWorld/AskFinishHatch",
    ["ActiveAssets: RequestRuntimeSnapshot"] = "RF/PenRoster/AskLiveSnapshot",
    ["ActiveAssets: RequestEquipLimit"]      = "RF/PenRoster/AskWearLimit",
    ["ActiveAssets: RequestEquip"]           = "RF/PenRoster/AskWear",
    ["ActiveAssets: RequestSell"]            = "RF/PenRoster/AskSale",
    ["OfflineAssets: GetSummary"]            = "RF/AwayEarnings/FetchSummary",
    ["OfflineAssets: Redeem"]                = "RF/AwayEarnings/AskCollect",
    ["Treadmills: RequestUpgrade"]           = "RF/Treadmill/AskTierRaise",
    ["ClientCharacter: RequestCharacterReset"] = "RE/RigSync/AskRigWipe",
}

-- ที่เก็บ remote  ลองของใหม่ก่อน แล้วค่อยตกไปของเก่า
function U.netRoot()
    if S.netRoot and S.netRoot.Parent then return S.netRoot end
    local pkg = ReplicatedStorage:FindFirstChild("Packages")
    local root = pkg and pkg:FindFirstChild("Networking")
    if not root then root = ReplicatedStorage:FindFirstChild("Network") end   -- เวอร์ชันเก่า
    S.netRoot = root
    return root
end

-- แปลงชื่อเก่า -> instance จริง  (แคชไว้ ไม่ต้องไล่หาใหม่ทุกครั้ง)
function U.remote(name)
    S.netCache = S.netCache or {}
    local hit = S.netCache[name]
    if hit and hit.Parent then return hit end

    local root = U.netRoot()
    if not root then return nil end

    -- 1) ชื่อใหม่ตามตารางแปลง  2) ชื่อที่ส่งมาตรงๆ (เผื่อเรียกด้วยชื่อใหม่อยู่แล้ว/เซิร์ฟเก่า)
    local found = (NET[name] and root:FindFirstChild(NET[name])) or root:FindFirstChild(name)

    -- 3) ยังไม่เจอ: เกมอาจสลับ RF/RE ของ endpoint นั้น ลองอีกฝั่งให้
    if not found and NET[name] then
        local alt = NET[name]:gsub("^RF/", "RE/"):gsub("^RE/", "RF/")
        found = root:FindFirstChild(alt)
    end

    S.netCache[name] = found
    if not found and CFG.Verbose then
        warn("[Egg] หา remote ไม่เจอ: " .. tostring(name) .. " -> " .. tostring(NET[name]))
    end
    return found
end

function U.invoke(name, timeout, ...)
    local remote = U.remote(name)
    if not remote then return false, "no remote " .. name end
    -- endpoint ที่เกมเปลี่ยนเป็น RemoteEvent แล้ว: ยิงอย่างเดียว ไม่มีค่าตอบกลับ
    if remote:IsA("RemoteEvent") or remote:IsA("UnreliableRemoteEvent") then
        local args0 = table.pack(...)
        pcall(function() remote:FireServer(table.unpack(args0, 1, args0.n)) end)
        return true, nil
    end
    local args = table.pack(...)
    local box = { done = false }
    task.spawn(function()
        local res = table.pack(pcall(function()
            return remote:InvokeServer(table.unpack(args, 1, args.n))
        end))
        box.done = true
        box.ok = res[1]
        box.v1, box.v2, box.v3 = res[2], res[3], res[4]
    end)
    local t0 = os.clock()
    while not box.done and os.clock() - t0 < (timeout or 8) do task.wait(0.05) end
    if not box.done then return false, "timeout" end
    if not box.ok then return false, tostring(box.v1) end
    return true, box.v1, box.v2, box.v3
end

function U.fire(name, ...)
    local remote = U.remote(name)
    if not remote then return end
    local args = table.pack(...)
    -- เผื่อ endpoint นั้นยังเป็น RemoteFunction อยู่ (ยิง FireServer ใส่จะ error)
    if remote:IsA("RemoteFunction") then
        task.spawn(function()
            pcall(function() remote:InvokeServer(table.unpack(args, 1, args.n)) end)
        end)
        return
    end
    pcall(function() remote:FireServer(table.unpack(args, 1, args.n)) end)
end

function U.char()
    local c = LP.Character
    if not c or not c.Parent then return nil end
    local hrp = c:FindFirstChild("HumanoidRootPart")
    local hum = c:FindFirstChildOfClass("Humanoid")
    if not hrp or not hum or hum.Health <= 0 then return nil end
    return c, hrp, hum
end

-- ระหว่าง humtween เรากด WalkSpeed เป็น 0 ไว้ ห้ามให้ตรรกะอื่น (เลือกโซน/ลู่วิ่ง/UI)
-- อ่านเจอ 0 ไม่งั้นมันจะคิดว่าเราช้าจนเข้าโซนไหนไม่ได้เลย -> คืนค่าจริงที่แคชไว้แทน
-- จุดกลางจาก config  รับได้ทั้ง Vector3 และ {x,y,z}  คืน nil ถ้าปิดไว้
function U.midPoint()
    local v = CFG.MidPoint
    if not v or v == false then return nil end
    if typeof(v) == "Vector3" then return v end
    if type(v) == "table" then
        local x, y, z = tonumber(v[1] or v.X or v.x), tonumber(v[2] or v.Y or v.y), tonumber(v[3] or v.Z or v.z)
        if x and y and z then return Vector3.new(x, y, z) end
    end
    return nil
end

function U.walkSpeed()
    if S.humLocked and S.realWalk and S.realWalk > 0 then return S.realWalk end
    local _, _, hum = U.char()
    return hum and hum.WalkSpeed or 16
end

--=====================================================================
--  GAME BINDINGS  (directory + remotes)
--=====================================================================
-- อัปเดต 2026-08-31 (PlaceVersion 447): โมดูลข้อมูลย้ายที่ทั้งหมด
--    ReplicatedStorage.Directory.*            ->  ReplicatedStorage.Data.*
--    ReplicatedStorage.Library.Modules.*      ->  ReplicatedStorage.Shared.Modules.*
--    ReplicatedStorage.Library.Client.EggCmds ->  ReplicatedStorage.Client.EggState (เปลี่ยนชื่อเมธอดด้วย)
-- ระวังกับดัก: ReplicatedStorage.Assets / .Mutations ที่เห็นอยู่ชั้นบนสุดเป็น
--    "Folder ของโมเดล" ไม่ใช่โมดูลข้อมูล  require ไปก็ไม่ได้ของ
local G = {}
do
    -- ลองหลายเส้นทางตามลำดับ เจออันไหนใช้อันนั้น (เผื่อเซิร์ฟเก่า/เกมย้อนเวอร์ชัน)
    local function tryPaths(paths, field)
        for _, path in ipairs(paths) do
            local node = ReplicatedStorage
            for seg in path:gmatch("[^%.]+") do
                node = node and node:FindFirstChild(seg)
            end
            if node and node:IsA("ModuleScript") then
                local ok, mod = pcall(require, node)
                if ok and type(mod) == "table" then
                    local v = field and mod[field] or mod
                    if type(v) == "table" then return v, path end
                end
            end
        end
        return nil
    end

    local path
    G.Assets, path = tryPaths({ "Data.Assets", "Directory.Assets" }, "Directory")
    G.Assets = G.Assets or {}
    G.Areas  = tryPaths({ "Data.Areas",  "Directory.Areas"  }, "Directory") or {}
    G.Guards = tryPaths({ "Data.Guards", "Directory.Guards" }, "Directory") or {}
    G.Mutations = tryPaths({ "Shared.Modules.Mutations", "Library.Modules.Mutations" })
    G.EggCmds   = tryPaths({ "Client.EggState", "Library.Client.EggCmds" })
    -- ลู่วิ่ง: Directory คีย์ด้วย _id ของ config (เช่น "DemonicTreadmill")
    -- และเลเวลปัจจุบันอยู่ในเซฟ ไม่ใช่ป้ายบน plot
    G.Tread     = tryPaths({ "Data.Treadmills", "Directory.Treadmills" })
    G.Save      = tryPaths({ "Shared.Save", "Library.Modules.Save" })

    if next(G.Assets) == nil then
        warn("[Egg] อ่านตาราง Assets ไม่ได้ - ไข่จะถูกตีมูลค่าเป็น 0 ทั้งหมด (เกมอาจอัปเดตอีกแล้ว)")
    end
    if next(G.Guards) == nil then
        warn("[Egg] อ่านตาราง Guards ไม่ได้ - จะไม่กล้าเข้าโซนไหนเลย")
    end
end

local EXP = 1.85 -- ค่ายกกำลังของ Scale ในสูตรรายได้ (ตรวจกับของจริงแล้ว)

local function mutationMulti(muts)
    if not muts or next(muts) == nil then return 1 end   -- ว่าง = ไม่ต้องเรียก (กัน error spam)
    -- v447: GetTotalMutationsEarningMulti โดนถอดออก ตัวใหม่ชื่อ EarningsFor
    -- (กินอินพุตแบบเดียวกัน คืนค่าเท่ากัน: {"Golden","Silver"} = 2.7 · {} = 1)
    if G.Mutations then
        local fn = G.Mutations.EarningsFor or G.Mutations.GetTotalMutationsEarningMulti
        if fn then
            local ok, m = pcall(fn, muts)
            if ok and type(m) == "number" and m > 0 then return m end
        end
    end
    -- fallback: ประมาณ 2.5 เท่าต่อ mutation
    local n = 0
    for _ in pairs(muts) do n = n + 1 end
    return 2.5 ^ n
end

-- มูลค่าไข่ 1 ฟอง = เงิน/วิ ของเป็ตที่จะฟักออกมา
local function eggValue(rec)
    local def = G.Assets[rec.AssetCategory]
    if not def then return 0 end
    local base = def.EarningRate or 0
    local scale = rec.AssetScale or rec.Scale or 1
    return base * (scale ^ EXP) * mutationMulti(rec.Mutations)
end

local function eggWeight(rec)
    local def = G.Assets[rec.AssetCategory]
    return (def and def.Egg and def.Egg.WeightKg) or 1
end

local function growthTime(cat)
    local def = G.Assets[cat]
    return (def and def.Egg and def.Egg.GrowthTime) or 30
end

local function guardSpeed(areaId)
    local g = G.Guards[areaId]
    return (g and g.WalkSpeed) or math.huge
end

--=====================================================================
--  PLOT  (หา plot ของตัวเอง / คอก / จุดอ้างอิง / ลู่วิ่ง)
--=====================================================================
local function resolvePlot()
    local plots = workspace:FindFirstChild("Plots")
    if not plots then return false end

    local found
    -- ทางหลัก: ถาม server ว่า slot ไหนเป็นของเรา
    local ok, state = U.invoke("Plots: RequestState", 6)
    if ok and type(state) == "table" and type(state.OwnersBySlot) == "table" then
        for slot, owner in pairs(state.OwnersBySlot) do
            if owner == LP.UserId then
                found = plots:FindFirstChild(tostring(slot))
                break
            end
        end
    end
    -- สำรอง: อ่านชื่อบนป้าย
    if not found then
        for _, p in ipairs(plots:GetChildren()) do
            local sign = p:FindFirstChild("PlotSign")
            if sign then
                for _, d in ipairs(sign:GetDescendants()) do
                    if d:IsA("TextLabel") and d.Text == LP.Name then found = p break end
                end
            end
            if found then break end
        end
    end
    if not found then return false end

    S.plot   = found
    S.origin = found:FindFirstChild("CenterPoint")
    local tu = found:FindFirstChild("ToUpdate")
    S.pen    = tu and tu:FindFirstChild("PetArea")
    S.tread  = found:FindFirstChild("TreadmillBottom")
    if not S.origin then S.origin = S.pen end
    return S.pen ~= nil and S.origin ~= nil
end

local function homePoint()
    if S.pen then return S.pen.Position + Vector3.new(0, 4, 0) end
    if S.origin then return S.origin.Position + Vector3.new(0, 4, 0) end
    local _, hrp = U.char()
    return hrp and hrp.Position or Vector3.new(0, 50, 0)
end

--=====================================================================
--  MOVEMENT
--    tween = ค่อยๆ เลื่อนต่อเนื่องทีละช่วงสั้นๆ เกาะพื้นตลอด  <<< default
--    walk  = เดินจริงด้วย MoveTo (ปลอดภัยที่สุด)
--    warp  = กระโดดตำแหน่ง  เซิร์ฟจับได้ ฆ่าทิ้ง  อย่าใช้
--=====================================================================
local M = {}

-- หาพื้นใต้จุดนั้น คืน nil ถ้าไม่เจอ (จะได้ไม่เผลอวางตัวลงเหว)
function M.groundY(pos)
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = { LP.Character }
    local hit = workspace:Raycast(pos + Vector3.new(0, 50, 0), Vector3.new(0, -400, 0), params)
    return hit and (hit.Position.Y + 3.2) or nil
end

-- ปล่อยตัวกลับสู่ physics ปกติ
function M.unlock()
    local _, hrp = U.char()
    if hrp and hrp.Anchored then
        hrp.Anchored = false
        hrp.AssemblyLinearVelocity = Vector3.zero
    end
    if S.humLocked then M.humRestore() end
end

-- ===== TWEEN MOVER =====
-- แบ่งทางเป็นช่วงสั้นๆ (TweenStep) แต่ละช่วง:
--   1. ยิง ray หาพื้นที่ปลายช่วง -> ตัวจะไม่ลอยและไม่จมพื้น
--   2. anchor ตัวไว้ แล้ว tween CFrame ไปแบบ Linear
--   3. ปลด anchor ล้างความเร็ว
-- เพราะขยับต่อเนื่องทีละนิด เซิร์ฟเลยไม่เห็นเป็น "การกระโดดตำแหน่ง"
-- ถ้าโดนดีดกลับติดๆ กัน = ตัดกลับไปโหมดเดินเองอัตโนมัติ
function M.tweenTo(target, tol)
    tol = tol or CFG.ArriveTol
    M.grabControls()
    local deadline = os.clock() + CFG.MoveTimeout
    local rollbacks, stalls = 0, 0

    while os.clock() < deadline do
        if not S.alive then M.unlock() return false end
        local _, hrp, hum = U.char()
        if not hrp or not hum or hum.Health <= 0 then M.unlock() return false end

        local delta = target - hrp.Position
        local flat = Vector3.new(delta.X, 0, delta.Z)
        if flat.Magnitude <= tol then M.unlock() return true end

        local step = math.min(CFG.TweenStep, flat.Magnitude)
        local dir = flat.Unit
        local nextPos = hrp.Position + dir * step
        local gy = M.groundY(nextPos)
        if gy then
            -- ไต่ขึ้น/ลงได้ไม่เกิน TweenClimb ต่อช่วง กันหลุดลงเหวหรือทะลุภูเขา
            local dy = math.clamp(gy - hrp.Position.Y, -CFG.TweenClimb, CFG.TweenClimb)
            nextPos = Vector3.new(nextPos.X, hrp.Position.Y + dy, nextPos.Z)
        end

        local speed = math.max(8, U.walkSpeed() * CFG.TweenSpeedMul)
        local capAbs = tonumber(CFG.TweenMaxSpeed) or 0
        if capAbs > 0 then speed = math.min(speed, capAbs) end
        local dur = math.max(0.03, step / speed)
        local from = hrp.Position

        hrp.Anchored = true
        local tw = TweenService:Create(
            hrp,
            TweenInfo.new(dur, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut),
            { CFrame = CFrame.new(nextPos, nextPos + dir) }
        )
        local done = false
        tw.Completed:Once(function() done = true end)
        tw:Play()
        local twEnd = os.clock() + dur + 0.4
        while not done and os.clock() < twEnd and S.alive do task.wait() end
        pcall(function() tw:Cancel() end)
        hrp.Anchored = false
        hrp.AssemblyLinearVelocity = Vector3.zero

        local moved = (hrp.Position - from).Magnitude
        if moved < step * 0.4 then
            rollbacks = rollbacks + 1
            stalls = stalls + 1
            if rollbacks >= CFG.TweenRollbackLimit then
                warn("[Egg] tween โดนเซิร์ฟดีดกลับ - สลับไปโหมด walk ถาวร")
                CFG.MoveMode = "walk"
                M.unlock()
                return M.walkTo(target, tol)
            end
            -- ติดกำแพง: กระโดดแล้วขยับออกด้านข้าง
            if stalls % 3 == 0 then
                pcall(function() hum.Jump = true end)
                task.wait(0.15)
            end
        else
            rollbacks = 0
            stalls = 0
        end
        task.wait()
    end
    M.unlock()
    return false
end


-- ===== HUMANOID-SWAP TWEEN MOVER  (MoveMode = "humtween")  <<< default =====
-- ต่างจากโหมด "tween" เก่าตรงที่ **ไม่ anchor ตัวเลย** - การ anchor คือสิ่งที่
-- ทำให้โหมดเก่าโดน BAC เตะ (Error 267) เพราะเซิร์ฟเห็นพาร์ตหยุดนิ่งแต่ตำแหน่งเดิน
-- วิธีนี้แทน:
--   1. โคลน Humanoid ตัวปัจจุบันออกมาสดๆ แล้วทิ้งตัวเก่า
--      -> คอนเนกชัน / สถานะ / ตัวจับที่เกาะ Humanoid ตัวเดิมอยู่ ขาดหมด
--      -> ใส่ Animator กลับให้ ไม่งั้นอนิเมชันหาย ดูออกทันที
--      -> BreakJointsOnDeath = false กันตัวขาดเป็นชิ้นถ้าโดนฆ่ากลางทาง
--   2. WalkSpeed = 0 ระหว่างเลื่อน -> ตัวละครไม่ออกแรงเดินสวนกับ tween
--      (ค่าจริงแคชไว้ที่ S.realWalk แล้ว U.walkSpeed() อ่านจากตรงนั้นแทน)
--   3. tween CFrame ของ HumanoidRootPart แบบ Linear + ล้าง Assembly velocity
--      ทุกช่วง -> ไม่มีความเร็วสะสม = ไม่โดนเช็ก "ความเร็วเกิน" และลงพื้นไม่ตาย
-- ยังแบ่งเป็นช่วงสั้นๆ เกาะพื้นอยู่ เพราะเช็ก "กระโดดตำแหน่ง" ของเกมนี้ยังอยู่
local HUM_PROPS = { "WalkSpeed", "JumpPower", "JumpHeight", "AutoRotate", "PlatformStand" }

-- สลับ Humanoid เป็นตัวโคลนสดๆ + กด WalkSpeed เป็น 0  คืน Humanoid ตัวใหม่
function M.humSwap()
    local char, hrp, hum = U.char()
    if not char or not hrp or not hum then return nil end

    -- แคชสเตตัสจริงตอนที่ยังไม่โดนกด (ตอนเริ่มเดินทาง) เท่านั้น
    if not S.humLocked or not S.humCache or S.humCache.Character ~= char then
        S.humCache = { Character = char }
        for _, prop in ipairs(HUM_PROPS) do
            pcall(function() S.humCache[prop] = hum[prop] end)
        end
        S.realWalk = S.humCache.WalkSpeed or hum.WalkSpeed
    end

    local clone
    local ok = pcall(function()
        hum.Archivable = true
        clone = hum:Clone()
        clone.BreakJointsOnDeath = false
        hum:Destroy()
        clone.Parent = char
        clone.WalkSpeed = 0
        if not clone:FindFirstChildOfClass("Animator") then
            local anim = Instance.new("Animator")
            anim.Parent = clone
        end
        -- กันดาเมจตกจากที่สูงเหมือน guardCharacter (Humanoid ตัวนี้เพิ่งเกิด ยังไม่โดนตั้ง)
        clone:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
        clone:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
    end)
    if not ok or not clone or not clone.Parent then
        warn("[Egg] humSwap ล้มเหลว - สลับไปโหมด " .. M.fallbackMode())
        S.humLocked = false
        return nil
    end

    hrp.AssemblyLinearVelocity, hrp.AssemblyAngularVelocity = Vector3.zero, Vector3.zero
    S.humLocked = true
    return clone
end

-- คืนสเตตัสจริงให้ตัวละคร  ต้องเรียกทุกครั้งที่เลิกเลื่อน ไม่งั้นผู้เล่นเดินไม่ได้
function M.humRestore()
    if S.humTween then
        pcall(function() S.humTween:Cancel() end)
        S.humTween = nil
    end
    local char = LP.Character
    local hrp = char and char:FindFirstChild("HumanoidRootPart")
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    if hum then
        -- WalkSpeed: คืนค่าเดิม **เฉพาะตอนที่ยังเป็น 0 ที่เรากดไว้เอง** เท่านั้น
        -- ถ้าเกมเซ็ตค่าใหม่มาระหว่างทาง (เช่นโดนหักความเร็วเพราะแบกไข่หนัก
        -- หรือได้บัฟจากลู่) ห้ามทับ ไม่งั้นเราจะวิ่งเร็วเกินค่าที่เซิร์ฟให้ = โดนจับ
        local cached = (S.humCache and S.humCache.Character == char) and S.humCache or nil
        if hum.WalkSpeed == 0 then
            local want = (cached and cached.WalkSpeed) or S.realWalk
            if want and want > 0 then pcall(function() hum.WalkSpeed = want end) end
        end
        if cached then
            for _, prop in ipairs(HUM_PROPS) do
                if prop ~= "WalkSpeed" and cached[prop] ~= nil then
                    pcall(function() hum[prop] = cached[prop] end)
                end
            end
        end
    end
    if hrp then
        hrp.AssemblyLinearVelocity, hrp.AssemblyAngularVelocity = Vector3.zero, Vector3.zero
    end
    S.humLocked = false
end

-- โหมดที่จะตกลงไปใช้เมื่อโดนจับได้  ห้ามคืน "humtween" เด็ดขาด ไม่งั้นเรียกวนไม่รู้จบ
-- (พรีเซ็ต "fast" ตั้ง MoveFallback = "humtween" ไว้ - ต้องดักตรงนี้)
function M.fallbackMode()
    local f = tostring(CFG.MoveFallback or "walk"):lower()
    if f == "humtween" or f == "warp" then return "walk" end
    return f
end

-- ความเร็วที่จะใช้ tween  studs/s
function M.humSpeed()
    local flat = tonumber(CFG.HumTweenSpeed) or 0
    local speed
    if flat > 0 then
        speed = flat
    else
        speed = math.max(8, U.walkSpeed() * (tonumber(CFG.HumTweenSpeedMul) or 2))
    end
    local cap = tonumber(CFG.HumTweenMaxSpeed) or 0
    if cap > 0 then speed = math.min(speed, cap) end
    return speed
end

-- เลื่อน 1 ช่วงไปที่ CFrame ที่กำหนด  คืน true ถ้า tween จบครบ
function M.humLeg(targetCF, speed)
    local _, hrp = U.char()
    if not hrp then return false end

    hrp.AssemblyLinearVelocity, hrp.AssemblyAngularVelocity = Vector3.zero, Vector3.zero

    local dist = (targetCF.Position - hrp.Position).Magnitude
    local dur = math.max(0.03, dist / math.max(1, speed))
    local tw = TweenService:Create(
        hrp,
        TweenInfo.new(dur, Enum.EasingStyle.Linear),
        { CFrame = targetCF }
    )
    S.humTween = tw

    local done, state = false, nil
    tw.Completed:Once(function(st) done, state = true, st end)
    tw:Play()

    local deadline = os.clock() + dur + 0.4
    while not done and os.clock() < deadline and S.alive do task.wait() end
    if S.humTween == tw then S.humTween = nil end
    if not done then pcall(function() tw:Cancel() end) end

    -- ปิดท้ายด้วยการเซ็ต CFrame ให้ตรงเป๊ะ กันหลุดทีละนิดสะสมจนเพี้ยน
    if state == Enum.PlaybackState.Completed and hrp.Parent then
        hrp.CFrame = targetCF
    end
    hrp.AssemblyLinearVelocity, hrp.AssemblyAngularVelocity = Vector3.zero, Vector3.zero
    return done
end

function M.humTweenTo(target, tol)
    tol = tol or CFG.ArriveTol
    M.grabControls()

    local deadline = os.clock() + CFG.MoveTimeout
    local rollbacks, legs = 0, 0
    local reclone = math.max(0, tonumber(CFG.HumTweenRecloneEvery) or 0)

    if not M.humSwap() then
        CFG.MoveMode = M.fallbackMode()
        return M.goTo(target, tol)
    end

    while os.clock() < deadline do
        if not S.alive then M.humRestore() return false end
        local _, hrp, hum = U.char()
        if not hrp or not hum or hum.Health <= 0 then M.humRestore() return false end

        local delta = target - hrp.Position
        local flat = Vector3.new(delta.X, 0, delta.Z)
        if flat.Magnitude <= tol then M.humRestore() return true end

        -- Humanoid โดนอะไรมาแทน/หลุด lock (เช่นเกิดใหม่) -> สลับใหม่
        if hum.WalkSpeed > 0 and S.humLocked then
            if not M.humSwap() then
                CFG.MoveMode = M.fallbackMode()
                M.humRestore()
                return M.goTo(target, tol)
            end
        end

        local step = math.min(CFG.HumTweenStep, flat.Magnitude)
        local dir = flat.Magnitude > 0.05 and flat.Unit or hrp.CFrame.LookVector
        local nextPos = hrp.Position + dir * step

        if CFG.HumTweenGround then
            local gy = M.groundY(nextPos)
            if gy then
                gy = gy - 3.2 + (tonumber(CFG.HumTweenHover) or 3.2)
                local dy = math.clamp(gy - hrp.Position.Y, -CFG.HumTweenClimb, CFG.HumTweenClimb)
                nextPos = Vector3.new(nextPos.X, hrp.Position.Y + dy, nextPos.Z)
            end
        end

        local from = hrp.Position
        M.humLeg(CFrame.new(nextPos, nextPos + dir), M.humSpeed())
        legs = legs + 1

        -- โคลนใหม่เป็นระยะถ้าตั้งไว้ (ตัวจับที่ผูก Humanoid จะไม่ทันเกาะ)
        if reclone > 0 and legs % reclone == 0 then M.humSwap() end

        local moved = ((hrp.Parent and hrp.Position or from) - from).Magnitude
        if moved < step * 0.4 then
            rollbacks = rollbacks + 1
            if rollbacks >= (CFG.HumTweenRollbackLimit or 3) then
                warn("[Egg] humtween โดนดีดกลับ - สลับไปโหมด " .. M.fallbackMode())
                CFG.MoveMode = M.fallbackMode()
                M.humRestore()
                return M.goTo(target, tol)
            end
        else
            rollbacks = 0
        end
        task.wait()
    end

    M.humRestore()
    return false
end

-- วาร์ปทีละช่วง ตรวจว่าขยับจริงทุกช่วง ถ้าโดนตีกลับก็ย่อระยะลง
function M.warpTo(target, tol)
    tol = tol or CFG.ArriveTol
    local step = CFG.Step
    local stuck = 0
    for _ = 1, CFG.HopTimeout do
        if not S.alive then return false end
        local _, hrp, hum = U.char()
        if not hrp then task.wait(0.3) return false end

        local delta = target - hrp.Position
        if delta.Magnitude <= tol then return true end

        local hop = delta.Magnitude > step and delta.Unit * step or delta
        local from = hrp.Position
        local dest = from + hop
        if CFG.GroundSnap and math.abs(hop.Y) < step * 0.5 then
            dest = Vector3.new(dest.X, M.groundY(dest), dest.Z)
        end

        local flat = Vector3.new(delta.X, 0, delta.Z)
        if flat.Magnitude > 0.05 then
            hrp.CFrame = CFrame.new(dest, dest + flat.Unit)
        else
            hrp.CFrame = CFrame.new(dest) * (hrp.CFrame - hrp.CFrame.Position)
        end
        -- ห้ามสะสมความเร็วตก ไม่งั้นลงพื้นแล้วตาย (ตายแล้วเกมนี้ไม่เกิดใหม่ให้)
        hrp.AssemblyLinearVelocity = Vector3.zero
        task.wait(CFG.Gap)

        local moved = (hrp.Position - from).Magnitude
        if moved < hop.Magnitude * 0.35 then
            stuck = stuck + 1
            step = math.max(12, step - 8)          -- เซิร์ฟตีกลับ -> ย่อระยะ
            if stuck > 12 then
                -- ดันขึ้นบนแล้วลองใหม่ (กันติดกำแพง)
                hrp.CFrame = hrp.CFrame + Vector3.new(0, 8, 0)
                task.wait(0.15)
                stuck = 0
                step = CFG.Step
            end
        else
            stuck = 0
            if step < CFG.Step then step = math.min(CFG.Step, step + 4) end
        end
    end
    return false
end

-- ควบคุม ControlModule: ต้องปิด input ของผู้เล่นก่อน ไม่งั้นมันจะยิง
-- Humanoid:Move(0,0,0) ทุกเฟรมมาล้าง MoveTo ทิ้ง (เดินได้แค่ ~4 studs/s)
function M.controls()
    if S.controlsObj then return S.controlsObj end
    local ok, pm = pcall(function() return require(LP.PlayerScripts.PlayerModule) end)
    if not ok then return nil end
    local ok2, c = pcall(function() return pm:GetControls() end)
    if ok2 then S.controlsObj = c end
    return S.controlsObj
end

function M.grabControls()
    local c = M.controls()
    if c and not S.controlsHeld then
        pcall(function() c:Disable() end)
        S.controlsHeld = true
    end
end

function M.releaseControls()
    local c = M.controls()
    if c and S.controlsHeld then
        pcall(function() c:Enable() end)
        S.controlsHeld = false
    end
end

-- เดินตรงไปหาจุดหมาย (ใช้ต่อจาก pathfinding ทีละ waypoint)
-- คืน "stuck" ถ้าดันกำแพงอยู่กับที่
function M.stepTo(point, tol, budget)
    local t0 = os.clock()
    local lastPos, stallAt = nil, os.clock()
    while os.clock() - t0 < (budget or 8) do
        if not S.alive then return false, "dead" end
        local _, hrp, hum = U.char()
        if not hrp then return false, "nochar" end

        local flat = Vector3.new(point.X, hrp.Position.Y, point.Z)
        if (flat - hrp.Position).Magnitude <= (tol or CFG.ArriveTol) then return true end
        hum:MoveTo(flat)

        -- ไม่ขยับ = ชนอะไรอยู่ กระโดดข้ามก่อน ถ้ายังไม่ไปค่อยบอกว่าติด
        if lastPos and (hrp.Position - lastPos).Magnitude < 1 then
            if os.clock() - stallAt > 1.0 then
                pcall(function() hum.Jump = true end)
                stallAt = os.clock()
                if os.clock() - t0 > 3 then return false, "stuck" end
            end
        else
            stallAt = os.clock()
        end
        lastPos = hrp.Position
        task.wait(0.1)
    end
    return false, "timeout"
end

-- คำนวณเส้นทางอ้อมสิ่งกีดขวางด้วย PathfindingService
function M.computePath(target)
    local _, hrp = U.char()
    if not hrp then return nil end
    local PS = game:GetService("PathfindingService")
    local ok, path = pcall(function()
        return PS:CreatePath({
            AgentRadius = 3,
            AgentHeight = 6,
            AgentCanJump = true,
            AgentCanClimb = false,
            WaypointSpacing = 8,
        })
    end)
    if not ok or not path then return nil end
    local ok2 = pcall(function() path:ComputeAsync(hrp.Position, target) end)
    if not ok2 or path.Status ~= Enum.PathStatus.Success then return nil end
    local wps = path:GetWaypoints()
    if #wps < 2 then return nil end
    return wps
end

-- เดินจริง ด้วยความเร็วจริงของตัวละคร (ปลอดภัย ไม่โดนดีด ไม่ตาย)
-- ลองเดินตรงก่อน ถ้าชนกำแพงค่อยเรียก pathfinding มาอ้อมให้
function M.walkTo(target, tol)
    tol = tol or CFG.ArriveTol
    M.grabControls()
    local deadline = os.clock() + CFG.MoveTimeout

    while os.clock() < deadline do
        if not S.alive then return false end
        local _, hrp = U.char()
        if not hrp then return false end
        if (Vector3.new(target.X, hrp.Position.Y, target.Z) - hrp.Position).Magnitude <= tol then
            return true
        end

        -- 1) ลองพุ่งตรงก่อน เร็วกว่ามากถ้าทางโล่ง
        local ok, why = M.stepTo(target, tol, math.min(10, deadline - os.clock()))
        if ok then return true end
        if why == "dead" or why == "nochar" then return false end

        -- 2) ตรงไม่ได้ = มีกำแพงขวาง ใช้ pathfinding อ้อม
        if not CFG.Pathfind then return false end
        local wps = M.computePath(target)
        if not wps then
            -- หาทางไม่เจอ: ถอยหลังสุ่มแล้วลองใหม่รอบหน้า
            local _, h2 = U.char()
            if h2 then
                local side = h2.CFrame.RightVector * (math.random(0, 1) == 0 and 14 or -14)
                M.stepTo(h2.Position + side, 4, 2.5)
            end
        else
            for i = 2, #wps do
                if not S.alive or os.clock() >= deadline then break end
                local wp = wps[i]
                local _, h3, hum3 = U.char()
                if not h3 then return false end
                if wp.Action == Enum.PathWaypointAction.Jump then
                    pcall(function() hum3.Jump = true end)
                end
                local reached, reason = M.stepTo(wp.Position, 5, 6)
                if not reached then
                    if reason == "dead" or reason == "nochar" then return false end
                    break -- เส้นทางเพี้ยน คำนวณใหม่รอบหน้า
                end
            end
        end
    end
    return false
end

function M.goTo(target, tol)
    local mode = CFG.MoveMode
    if mode == "warp" then return M.warpTo(target, tol) end   -- อันตราย
    if mode == "walk" then return M.walkTo(target, tol) end
    if mode == "tween" then return M.tweenTo(target, tol) end -- แบบ anchor (โดน BAC มาแล้ว)
    return M.humTweenTo(target, tol)                          -- humtween = default
end

-- แวะจุดกลางก่อน (ข้ามถ้าอยู่ใกล้อยู่แล้ว)  คืน true ถ้าไม่ต้องแวะ/แวะสำเร็จ
-- อยู่บน M ไม่ใช่ U เพราะต้องเรียก M.goTo ซึ่ง local M ประกาศทีหลังบล็อค U
function M.viaMid(label)
    local mid = U.midPoint()
    if not mid then return true end
    local _, hrp = U.char()
    local tol = tonumber(CFG.MidPointTol) or 12
    if hrp and (hrp.Position - mid).Magnitude <= tol then return true end
    S.status = "-> middle" .. (label and (" (" .. label .. ")") or "")
    return M.goTo(mid, tol)
end

function M.goHome()
    if CFG.MidPointHome then M.viaMid("home") end
    local ok = M.goTo(homePoint(), 6)
    task.wait(CFG.WarpSettle)
    return ok
end

--=====================================================================
--  AREA EGGS  (snapshot / จัดอันดับ / เลือกเป้าหมาย)
--=====================================================================
local A = {}

function A.snapshot()
    local ok, snap = U.invoke("Eggs: RequestAreaEggSnapshot", 8)
    if not ok or type(snap) ~= "table" then return {} end
    return snap.Records or {}
end


--=====================================================================
--  READ-ONLY EGG SCANNER / CROSS-SERVER SCOREBOARD
--  สแกนข้อมูลที่เซิร์ฟเวอร์ปัจจุบันเปิดเผยเท่านั้น ไม่สั่งขโมย/ย้ายเซิร์ฟเวอร์
--  หาก executor รองรับ readfile/writefile จะเก็บผลไว้ให้เปรียบเทียบหลังผู้ใช้ย้ายเซิร์ฟเอง
--=====================================================================
local EggScanner = {
    File = "egg_scanner_best.json",
    Busy = false,
    LastScan = 0,
    HopBusy = false,
    LastHop = 0,
    HopCooldown = 20,
}

local function scannerLoad()
    if type(readfile) ~= "function" or type(isfile) ~= "function" then
        return { Servers = {}, StorageAvailable = false }
    end
    local okExists, exists = pcall(isfile, EggScanner.File)
    if not okExists or not exists then
        return { Servers = {}, StorageAvailable = true }
    end
    local okRead, raw = pcall(readfile, EggScanner.File)
    if not okRead or type(raw) ~= "string" then
        return { Servers = {}, StorageAvailable = true }
    end
    local okDecode, data = pcall(function()
        return game:GetService("HttpService"):JSONDecode(raw)
    end)
    if okDecode and type(data) == "table" then
        data.Servers = type(data.Servers) == "table" and data.Servers or {}
        data.StorageAvailable = true
        return data
    end
    return { Servers = {}, StorageAvailable = true }
end

local function scannerSave(data)
    if type(writefile) ~= "function" then return false, "writefile unavailable" end
    local okEncode, raw = pcall(function()
        return game:GetService("HttpService"):JSONEncode(data)
    end)
    if not okEncode then return false, "JSON encoding failed" end
    local okWrite, result = pcall(writefile, EggScanner.File, raw)
    if not okWrite then return false, tostring(result) end
    return true
end

local function scannerMutationText(muts)
    if type(muts) ~= "table" then
        if muts == nil then return "None" end
        return tostring(muts)
    end
    local names = {}
    for k, v in pairs(muts) do
        if type(k) == "number" then
            names[#names + 1] = tostring(v)
        elseif v then
            names[#names + 1] = tostring(k)
        end
    end
    table.sort(names)
    return #names > 0 and table.concat(names, ", ") or "None"
end

function EggScanner.Scan()
    if EggScanner.Busy then
        warn("[EggScanner] Scan already running; skipped duplicate request.")
        return nil, nil, {}, "busy"
    end
    EggScanner.Busy = true
    local ok, best, globalBest, ranked, status = pcall(function()
        local records = A.snapshot()
        if type(records) ~= "table" then records = {} end
        local serverId = tostring(game.JobId or "unknown")
        local placeId = tostring(game.PlaceId or "unknown")
        local rankedLocal = {}
        local bestLocal

        for _, rec in pairs(records) do
            if type(rec) == "table" and rec.AssetCategory then
                local value = tonumber(eggValue(rec)) or 0
                if value > 0 and value == value and value < math.huge then
                    local item = {
                        Name = tostring(rec.AssetCategory),
                        Area = tostring(rec.AreaId or "?"),
                        CPS = value,
                        Scale = tonumber(rec.AssetScale or rec.Scale) or 1,
                        Mutation = scannerMutationText(rec.Mutations),
                        ServerId = serverId,
                        PlaceId = placeId,
                        SeenAt = os.date("!%Y-%m-%dT%H:%M:%SZ"),
                    }
                    rankedLocal[#rankedLocal + 1] = item
                    if not bestLocal or item.CPS > bestLocal.CPS then bestLocal = item end
                end
            end
        end
        table.sort(rankedLocal, function(a, b) return a.CPS > b.CPS end)

        local all = scannerLoad()
        all.Servers = type(all.Servers) == "table" and all.Servers or {}
        all.Servers[serverId] = {
            ScannedAt = os.date("!%Y-%m-%dT%H:%M:%SZ"),
            PlaceId = placeId,
            Count = #rankedLocal,
            Best = bestLocal,
        }
        local global
        for _, server in pairs(all.Servers) do
            local candidate = type(server) == "table" and server.Best or nil
            local cps = candidate and tonumber(candidate.CPS)
            if cps and cps > 0 and (not global or cps > global.CPS) then
                global = { Name = tostring(candidate.Name or "?"), CPS = cps,
                    ServerId = tostring(candidate.ServerId or "?"), PlaceId = tostring(candidate.PlaceId or "?"),
                    Area = tostring(candidate.Area or "?"), SeenAt = tostring(candidate.SeenAt or "?") }
            end
        end
        all.GlobalBest = global
        all.LastServerId = serverId
        all.StorageAvailable = nil
        local saved, saveErr = scannerSave(all)

        print(('[EggScanner] server=%s | eggs=%d | best=%s | CPS=%.2f'):format(
            serverId, #rankedLocal, bestLocal and bestLocal.Name or "none", bestLocal and bestLocal.CPS or 0))
        if global then
            print(('[EggScanner] best saved server: %s | %.2f CPS | server=%s | area=%s'):format(
                global.Name, global.CPS, global.ServerId, global.Area))
        end
        for i = 1, math.min(5, #rankedLocal) do
            local e = rankedLocal[i]
            print(('[EggScanner] #%d %s | %.2f CPS | area=%s | scale=%.2f | mutations=%s'):format(
                i, e.Name, e.CPS, e.Area, e.Scale, e.Mutation))
        end
        if #rankedLocal == 0 then
            warn('[EggScanner] No valid egg records returned. Snapshot may be unavailable or empty in this server.')
        end
        if not saved then
            warn('[EggScanner] Results are not persisted between sessions: ' .. tostring(saveErr))
        end
        return bestLocal, global, rankedLocal, saved and "saved" or "memory-only"
    end)
    EggScanner.Busy = false
    if not ok then
        warn('[EggScanner] Scan failed: ' .. tostring(best))
        return nil, nil, {}, "error"
    end
    EggScanner.LastScan = os.clock()
    return best, globalBest, ranked, status
end

_G.EggScanNow = function() return EggScanner.Scan() end
_G.EggScanResults = function() return scannerLoad() end

-- Uses Roblox's normal rejoin request; it cannot choose a server by egg CPS.
-- Cooldown prevents repeated taps from issuing overlapping teleport requests.
_G.EggHop = function()
    if EggScanner.HopBusy then
        warn('[EggScanner] A hop request is already pending.')
        return false
    end
    local now = os.clock()
    if EggScanner.LastHop > 0 and now - EggScanner.LastHop < EggScanner.HopCooldown then
        warn(('[EggScanner] Please wait %d seconds before trying to rejoin again.'):format(
            math.ceil(EggScanner.HopCooldown - (now - EggScanner.LastHop))))
        return false
    end
    local ok, err = pcall(function()
        local Players = game:GetService('Players')
        local TeleportService = game:GetService('TeleportService')
        local player = Players.LocalPlayer
        if not player then error('LocalPlayer unavailable') end
        EggScanner.HopBusy = true
        EggScanner.LastHop = now
        TeleportService:Teleport(game.PlaceId, player)
    end)
    if not ok then
        EggScanner.HopBusy = false
        warn('[EggScanner] Rejoin request failed: ' .. tostring(err))
        return false
    end
    print('[EggScanner] Rejoin requested. Roblox chooses the destination; a different/better server is not guaranteed.')
    return true
end

function A.areaAllowed(areaId)
    local want = CFG.Area
    if type(want) == "table" then
        for _, a in ipairs(want) do if a == areaId then return true end end
        return false
    end
    if type(want) == "string" and want ~= "ALL" and want ~= "" then
        return want == areaId
    end
    return true
end

-- guard ที่ช้าที่สุดในเกม (= โซนเริ่มต้น)
function A.easiestGuard()
    if S.easiestGuard then return S.easiestGuard end
    local best
    for id in pairs(G.Guards) do
        local g = guardSpeed(id)
        if g < math.huge and (not best or g < best) then best = g end
    end
    S.easiestGuard = best or 16
    return S.easiestGuard
end

-- วิ่งหนี guard ทันไหม (คิดรวมการถูกหน่วงตอนแบกไข่)
function A.areaSafe(areaId, carryMul)
    if not CFG.RespectGuardSpeed then return true end
    local g = guardSpeed(areaId)
    if g == math.huge then return false end

    -- โซนง่ายสุดเข้าได้เสมอ
    -- บัญชีใหม่ WalkSpeed 16 = เท่า guard Forest พอดี ถ้าคิดเป๊ะๆ จะไม่ผ่านสักโซน
    -- แต่ guard เริ่มหลับ + ตื่นช้า (RunBackWakeDelayRequired) เลยมีเวลาคว้าแล้ววิ่ง
    if g <= A.easiestGuard() then return true end

    local mine = U.walkSpeed() * (carryMul or 1)
    return mine >= g * CFG.SpeedSafety
end

-- เกณฑ์ขั้นต่ำของไข่ที่คุ้มค่าจะไปเก็บ
function A.minRate(ownedBest)
    local m = U.parseAmount(CFG.MinEggRate)
    if m > 0 then return m end
    return (ownedBest or 0) * 0.01
end

-- คืน list ไข่ที่เอาได้ "เรียงจากตัวที่ทำเงินมากสุด -> น้อยสุด" เสมอ
-- ตัวคุ้มสุดถูกเก็บก่อนทุกครั้ง ต่อให้อยู่ไกลกว่าก็ตาม
-- (ค่าเท่ากันค่อยเอาตัวที่ใกล้กว่า)
function A.candidates(ownedBest)
    local list = {}
    local floor = A.minRate(ownedBest)
    local _, hrp = U.char()
    local me = hrp and hrp.Position or Vector3.zero

    for _, rec in pairs(A.snapshot()) do
        if rec.State == "Slot" and A.areaAllowed(rec.AreaId) then
            local mul = math.clamp(1 - 0.04 * eggWeight(rec), 0.25, 1)
            if A.areaSafe(rec.AreaId, mul) then
                local val = eggValue(rec)
                if val >= floor then
                    list[#list + 1] = {
                        rec = rec,
                        value = val,
                        carryMul = mul,
                        dist = (rec.BottomCFrame.Position - me).Magnitude,
                    }
                end
            end
        end
    end

    if CFG.PreferBest == false then
        -- โหมดเน้นเร็ว: เอาตัวใกล้ก่อน
        table.sort(list, function(a, b) return a.dist < b.dist end)
    else
        table.sort(list, function(a, b)
            if a.value ~= b.value then return a.value > b.value end
            return a.dist < b.dist
        end)
    end
    return list
end

--=====================================================================
--  STEAL  (กดปุ่ม CarryAreaEgg -> แบกกลับฐาน)
--=====================================================================
local promptCache = { list = {}, at = 0 }

local function refreshPrompts()
    if os.clock() - promptCache.at < 3 and #promptCache.list > 0 then return promptCache.list end
    local list = {}
    for _, d in ipairs(workspace:GetDescendants()) do
        if d:IsA("ProximityPrompt") and d.Name == "CarryAreaEgg" then
            local p = d.Parent
            if p and p:IsA("BasePart") then list[#list + 1] = { prompt = d, part = p } end
        end
    end
    promptCache.list, promptCache.at = list, os.clock()
    return list
end

local function promptNear(pos, maxDist)
    local best, bd
    for _, e in ipairs(refreshPrompts()) do
        if e.prompt.Parent then
            local d = (e.part.Position - pos).Magnitude
            if (not bd or d < bd) then best, bd = e.prompt, d end
        end
    end
    if best and bd and bd <= (maxDist or 14) then return best, bd end
    return nil, bd
end

-- ขโมย 1 ฟอง: วาร์ปไป -> กดปุ่ม -> ยืนยันว่าถืออยู่
local function stealEgg(cand)
    local rec = cand.rec
    local eggPos = rec.BottomCFrame.Position

    -- แวะจุดกลางก่อน แล้วค่อยพุ่งเข้าไข่
    M.viaMid(rec.AreaId)
    if not S.alive then return false end

    S.status = "steal " .. tostring(rec.AssetCategory) .. " @ " .. tostring(rec.AreaId)
    if not M.goTo(eggPos + Vector3.new(0, 3, 0), 4) then
        S.failed = S.failed + 1
        return false
    end
    task.wait(CFG.WarpSettle)

    for attempt = 1, math.max(1, CFG.RetryGrab) do
        if not S.alive then return false end

        -- ทางหลัก: ยิง remote ตัวเดียวกับที่ปุ่มในเกมเรียก
        -- ถอดมาจาก StarterPlayerScripts.Game.AreaEggs -> bindPrompt.Triggered:
        --     EggState.CarryFieldEgg(rec.Uid, slotKey)
        --       = AskFieldEggCarry:InvokeServer{ Uid = ..., FirstAreaSlotKey = ... }
        -- ดีกว่าใช้ปุ่ม เพราะ Prompt.Enabled เกมคิดฝั่ง client ล้วน (เซิร์ฟไม่เห็น)
        -- แถมไม่ต้องรอ hold 1.2 วิ  ส่วน FirstAreaSlotKey ใช้เฉพาะไข่ "โซนแรก"
        -- ซึ่งไข่ปกติไม่ใช่ -> ส่ง nil ไป
        local carried = false
        if CFG.StealViaRemote ~= false then
            local ok, res, why = U.invoke("Eggs: RequestAreaEggCarry", 6, { Uid = rec.Uid })
            carried = ok and res and true or false
            if ok and not res and CFG.Verbose and attempt == 1 then
                log("carry remote refused:", tostring(why))
            end
        end

        -- สำรอง: กดปุ่มแบบเดิม (เผื่อ remote เปลี่ยน signature อีก)
        if not carried then
            promptCache.at = 0
            local prompt = promptNear(eggPos, 16)
            if prompt then
                pcall(function() fireproximityprompt(prompt, 1) end)
            end
        end
        local t0 = os.clock()
        while os.clock() - t0 < CFG.GrabTimeout do
            if S.carrying then
                S.stolen = S.stolen + 1
                S.carryMul = S.carrying.SpeedMultiplier or cand.carryMul or 1
                log("grabbed", S.carrying.AssetCategory, "(" .. U.short(cand.value) .. "/s)")
                return true
            end
            task.wait(0.1)
        end
        -- ยังไม่ติด: ขยับเข้าไปอีกนิดแล้วลองใหม่
        M.goTo(eggPos + Vector3.new(0, 2, 0), 2)
        task.wait(0.3)
    end
    S.failed = S.failed + 1
    return false
end

-- แบกกลับฐาน -> เข้าเขตคอกแล้วเซิร์ฟจะเปลี่ยนไข่เป็น Tool ให้เอง
local function carryHome()
    S.status = "carry home"
    M.goTo(homePoint(), 6)

    -- ถึงคอกแล้วเซิร์ฟจะเก็บไข่ให้เอง รอเฉยๆ ก่อน
    local t0 = os.clock()
    while os.clock() - t0 < CFG.ClaimTimeout do
        if not S.carrying then return true end
        task.wait(0.2)
        -- ยังไม่เข้า: เดินวนในคอกเผื่อ trigger ไม่ติด (เริ่มหลังรอไปแล้ว 2 วิ)
        if os.clock() - t0 > 2 then
            M.goTo(homePoint() + Vector3.new(math.random(-6, 6), 0, math.random(-6, 6)), 4)
        end
    end
    return not S.carrying
end

--=====================================================================
--  BASE WORK  (วางไข่ / ฟัก / วางเป็ต / ขาย)
--=====================================================================
local B = {}

function B.myEggRecords()
    local out = {}
    local ok, snap = U.invoke("Eggs: RequestRuntimeSnapshot", 8)
    if not ok or type(snap) ~= "table" then return out end
    for _, entry in pairs(snap) do
        if type(entry) == "table" and entry.OwnerUserId == LP.UserId then
            for uid, rec in pairs(entry.Records or {}) do out[uid] = rec end
        end
    end
    return out
end

function B.myPets()
    local out, count = {}, 0
    local ok, snap = U.invoke("ActiveAssets: RequestRuntimeSnapshot", 8)
    if not ok or type(snap) ~= "table" then return out, 0 end
    for _, entry in pairs(snap) do
        if type(entry) == "table" and entry.OwnerUserId == LP.UserId then
            for uid, rec in pairs(entry.Records or {}) do
                out[#out + 1] = { uid = uid, mps = rec.MoneyPerSecond or 0, data = rec.ItemData or {} }
                count = count + 1
            end
        end
    end
    table.sort(out, function(a, b) return a.mps > b.mps end)
    return out, count
end

function B.equipLimit()
    local ok, n = U.invoke("ActiveAssets: RequestEquipLimit", 6)
    if ok and type(n) == "number" then return n end
    return 13
end

-- Tool ในกระเป๋า/มือ ที่เป็นไข่หรือเป็ต
function B.tools(itemType)
    local out = {}
    local function scan(container)
        if not container then return end
        for _, c in ipairs(container:GetChildren()) do
            if c:IsA("Tool") and c:GetAttribute("ItemType") == itemType then
                out[#out + 1] = c
            end
        end
    end
    scan(LP:FindFirstChild("Backpack"))
    scan(LP.Character)
    return out
end

-- หาที่ว่างในคอกสำหรับวางไข่
function B.freeSpot(taken)
    if not S.pen or not S.origin then return nil end
    local size = S.pen.Size
    local mx = math.max(4, size.X / 2 - 5)
    local mz = math.max(4, size.Z / 2 - 5)
    for _ = 1, 60 do
        local dx = math.random(-math.floor(mx), math.floor(mx))
        local dz = math.random(-math.floor(mz), math.floor(mz))
        local world = S.pen.CFrame * CFrame.new(dx, size.Y / 2 + 1, dz)
        local clear = true
        for _, p in ipairs(taken) do
            if (p - world.Position).Magnitude < 6 then clear = false break end
        end
        if clear then return world end
    end
    return S.pen.CFrame * CFrame.new(math.random(-10, 10), size.Y / 2 + 1, math.random(-10, 10))
end

function B.placeEggs()
    if not CFG.AutoPlace then return end
    if not S.pen or not S.origin then return end

    -- ไข่ที่ยึดมาแล้วจะอยู่ใน "record" ไม่ใช่ Tool ในกระเป๋า
    -- (จะเป็น Tool ก็ต่อเมื่อสั่ง RequestEquipTool เท่านั้น - วางไม่ต้องถือ)
    -- record ที่ยังไม่วาง = ไม่มีฟิลด์ Placement
    local pending, taken = {}, {}
    for uid, rec in pairs(B.myEggRecords()) do
        if rec.Placement then
            if rec.Placement.LocalCFrame then
                taken[#taken + 1] = (S.origin.CFrame * rec.Placement.LocalCFrame).Position
            end
        else
            pending[#pending + 1] = { uid = uid, rec = rec }
        end
    end
    if #pending == 0 then return end

    for _, item in ipairs(pending) do
        if not S.alive then return end
        local world = B.freeSpot(taken)
        if world then
            local localCF = S.origin.CFrame:ToObjectSpace(world)
            local ok, res, reason = U.invoke("Eggs: RequestPlaceEgg", 8, { Uid = item.uid, LocalCFrame = localCF })
            if ok and res then
                S.placed = S.placed + 1
                taken[#taken + 1] = world.Position
                log("placed", item.rec.AssetCategory)
            elseif CFG.Verbose then
                log("place failed", item.rec.AssetCategory, tostring(reason or res))
            end
            task.wait(0.15)
        end
    end
end

function B.hatchReady()
    if not CFG.AutoHatch then return end
    local now = workspace:GetServerTimeNow()
    for uid, rec in pairs(B.myEggRecords()) do
        if not S.alive then return end
        if rec.Placement then
            local ready
            -- v447: EggCmds.IsLocalEggReady -> EggState.IsReadyToHatch
            if G.EggCmds then
                local fn = G.EggCmds.IsReadyToHatch or G.EggCmds.IsLocalEggReady
                if fn then
                    local ok, r = pcall(fn, uid)
                    if ok then ready = r end
                end
            end
            if ready == nil then
                local need = growthTime(rec.AssetCategory) / math.max(0.01, rec.GrowthSpeedMultiplier or 1)
                ready = (now - (rec.Placement.PlacedAt or now)) >= need
            end
            if ready then
                local ok, res = U.invoke("Eggs: RequestHatchEgg", 8, uid)
                if ok and res then
                    task.wait(0.9)
                    local ok2, res2, _, petUid = U.invoke("Eggs: RequestCompleteHatchEgg", 8, uid)
                    if ok2 and res2 then
                        S.hatched = S.hatched + 1
                        log("hatched", rec.AssetCategory, petUid and ("-> " .. tostring(petUid):sub(1, 8)) or "")
                    end
                end
                task.wait(0.2)
            end
        end
    end
end

-- มูลค่าเป็ตที่ยังอยู่ในกระเป๋า (ยังไม่ลงคอก)
function B.bagPetValue(tool)
    local cat = tool:GetAttribute("Category")
    local def = G.Assets[cat]
    if not def then return 0 end
    local scale = tonumber(tool:GetAttribute("Scale")) or 1
    -- attribute Mutations เป็น string เช่น "Golden,Silver" (ว่าง = ไม่มี)
    -- ต้องแตกเป็น array ของ "ชื่อ" เอง
    -- (ExtractMutationsFromString คืน object ของ mutation ซึ่ง GetTotalMutationsEarningMulti กินไม่ได้)
    local muts = {}
    for name in tostring(tool:GetAttribute("Mutations") or ""):gmatch("[^,%s]+") do
        muts[#muts + 1] = name
    end
    return (def.EarningRate or 0) * (scale ^ EXP) * mutationMulti(muts)
end

-- ลงคอก + ขายตัวที่แย่ที่สุดเมื่อเต็ม
function B.equipAndSell()
    local bag = B.tools("Asset")
    if #bag == 0 and not CFG.AutoSell then return end

    local pets, count = B.myPets()
    local limit = B.equipLimit() - math.max(0, CFG.KeepExtra)
    local keepAbove = U.parseAmount(CFG.KeepAbove)

    -- เรียงเป็ตในกระเป๋า: ดีสุดก่อน
    table.sort(bag, function(a, b) return B.bagPetValue(a) > B.bagPetValue(b) end)

    for _, tool in ipairs(bag) do
        if not S.alive then return end
        local uid = tool:GetAttribute("UID")
        if not uid then continue end
        local val = B.bagPetValue(tool)

        if count < limit then
            if CFG.AutoEquip then
                local ok, res = U.invoke("ActiveAssets: RequestEquip", 8, uid)
                if ok and res then
                    count = count + 1
                    table.insert(pets, { uid = uid, mps = val, data = {} })
                    table.sort(pets, function(a, b) return a.mps > b.mps end)
                end
                task.wait(0.12)
            end
        elseif CFG.AutoSell then
            -- คอกเต็ม: ตัวใหม่ดีกว่าตัวท้ายคอกไหม
            local worst = pets[#pets]
            if worst and val > worst.mps and (keepAbove <= 0 or worst.mps < keepAbove) then
                local ok, res = U.invoke("ActiveAssets: RequestSell", 8, worst.uid)
                if ok and res then
                    S.sold = S.sold + 1
                    table.remove(pets, #pets)
                    count = count - 1
                    log("sold worst", U.short(worst.mps) .. "/s  <-  " .. U.short(val) .. "/s")
                    task.wait(0.12)
                    local ok2, res2 = U.invoke("ActiveAssets: RequestEquip", 8, uid)
                    if ok2 and res2 then
                        count = count + 1
                        table.insert(pets, { uid = uid, mps = val, data = {} })
                        table.sort(pets, function(a, b) return a.mps > b.mps end)
                    end
                end
            elseif CFG.SellBackpack and worst and val <= worst.mps and (keepAbove <= 0 or val < keepAbove) then
                -- ตัวใหม่แย่กว่าทุกตัวในคอก -> ขายทิ้ง
                local ok, res = U.invoke("ActiveAssets: RequestSell", 8, uid)
                if ok and res then
                    S.sold = S.sold + 1
                    log("sold bag pet", U.short(val) .. "/s")
                end
            end
            task.wait(0.12)
        end
    end
end

function B.claimOffline()
    if not CFG.AutoClaimOffline then return end
    local ok, sum = U.invoke("OfflineAssets: GetSummary", 6)
    if ok and type(sum) == "table" and (sum.ClaimableAmount or 0) > 0 then
        U.invoke("OfflineAssets: Redeem", 8)
        log("claimed offline", U.short(sum.ClaimableAmount))
    end
end

-- เงินสดปัจจุบัน (อ่านจาก GUI เพราะ leaderstats มีแต่ Money/s)
function B.cash()
    local pg = LP:FindFirstChild("PlayerGui")
    local money = pg and pg:FindFirstChild("Money")
    if not money then return 0 end
    for _, d in ipairs(money:GetDescendants()) do
        if d:IsA("TextLabel") and d.Name == "Money" then
            return U.parseAmount((d.Text or ""):gsub("%$", ""))
        end
    end
    return 0
end

-- ลู่เรียงตามราคา: index = "Level" บนป้ายพอดี
-- Lv1 Treadmill x2 · Lv2 Sci-Fi x5 · Lv3 Flame x12 · Lv4 Celebrity x30
-- Lv5 Golden x80 · Lv6 The Freeze x100 · Lv7 Lucky Block x200
-- Lv8 Hacker x500 · Lv9 Demonic x1000 · Lv10 Angelic x2000
function B.treadmillTiers()
    if S.tiers then return S.tiers end
    if not G.Tread then return {} end
    local TD = G.Tread.Directory or G.Tread
    local list = {}
    for id, cfg in pairs(TD) do
        -- v447: AskTierRaise กิน"_id ของ config" (เช่น "DemonicTreadmill") ไม่ใช่ id ของตัวลู่
        list[#list + 1] = {
            id    = cfg._id or id,
            price = cfg.Price or 0,
            mult  = cfg.SpeedMultiplier or 0,
            level = cfg.UpgradeLevel,
        }
    end
    table.sort(list, function(a, b) return a.price < b.price end)
    S.tiers = list
    return list
end

-- เลเวลลู่ปัจจุบัน: อ่านจากเซฟก่อน (แม่นสุด) ค่อยตกไปอ่านป้ายบน plot
function B.treadLevel()
    if G.Save and G.Save.Get then
        local ok, save = pcall(G.Save.Get)
        if ok and type(save) == "table" and tonumber(save.TreadmillUpgradeLevel) then
            return tonumber(save.TreadmillUpgradeLevel)
        end
    end
    return padLevel(S.plot and S.plot:FindFirstChild("TreadmillUpgrade"))
end

-- อ่านเลเวลปัจจุบันจากป้ายบนแท่นอัปเกรด ("Level 6 > Level 7")
local function padLevel(model)
    if not model then return nil end
    for _, d in ipairs(model:GetDescendants()) do
        if d:IsA("TextLabel") then
            local cur, nxt = tostring(d.Text):match("Level%s+(%d+)%s*>%s*Level%s+(%d+)")
            if cur then return tonumber(cur), tonumber(nxt) end
        end
    end
    return nil
end

function B.upgradeTreadmill()
    if not (CFG.AutoUpgrade and CFG.UpgradeTreadmill) then return end
    local cur = B.treadLevel()
    local tiers = B.treadmillTiers()
    if #tiers == 0 then return end

    -- เกมเลือกเป้าหมายด้วย GetByUpgradeLevel(level + 1) -> ใช้ทางเดียวกัน
    local target
    if cur and G.Tread and G.Tread.GetByUpgradeLevel then
        local ok, cfg = pcall(G.Tread.GetByUpgradeLevel, cur + 1)
        if ok and type(cfg) == "table" and cfg._id then
            target = { id = cfg._id, price = cfg.Price or 0, mult = cfg.SpeedMultiplier or 0 }
        end
    end
    -- สำรอง: ไล่จากถูกไปแพง ตัวถัดจากเลเวลปัจจุบัน
    if not target then target = tiers[(cur and (cur + 1)) or 2] end
    if not target then return end          -- สุดทางแล้ว

    local cap = U.parseAmount(CFG.MaxTreadmillPrice)
    if cap > 0 and target.price > cap then return end
    local cash = B.cash()
    if cash > 0 and target.price > cash then return end

    local ok, res, reason = U.invoke("Treadmills: RequestUpgrade", 8, target.id)
    if ok and res then
        S.upgrades = S.upgrades + 1
        log(("upgraded treadmill -> %s (x%s) for $%s"):format(target.id, tostring(target.mult), U.short(target.price)))
    elseif CFG.Verbose and reason then
        log("treadmill upgrade:", tostring(reason))
    end
end

function B.upgradePen()
    if not (CFG.AutoUpgrade and CFG.UpgradePen) then return end
    local pad = S.plot and S.plot:FindFirstChild("PlotUpgrade")
    local cur = padLevel(pad)
    -- อ่านราคาจากป้าย ถ้าเงินไม่พอก็ไม่ต้องยิง
    local cost
    if pad then
        for _, d in ipairs(pad:GetDescendants()) do
            if d:IsA("TextLabel") then
                local c = tostring(d.Text):match("^%$([%d%.,]+[kKmMbBtTqQ]?)$")
                if c then
                    local v = U.parseAmount(c)
                    if v and (not cost or v > cost) then cost = v end
                end
            end
        end
    end
    local cap = U.parseAmount(CFG.MaxPenPrice)
    if cap > 0 and cost and cost > cap then return end
    if cost and cost > B.cash() then return end

    U.fire("Plots: RequestBaseUpgrade")
    task.wait(0.5)
    local after = padLevel(pad)
    if cur and after and after > cur then
        S.upgrades = S.upgrades + 1
        log(("upgraded pen -> Level %d for $%s"):format(after, U.short(cost or 0)))
    end
end

function B.upgrade()
    if not CFG.AutoUpgrade then return end
    if (S.loops - (S.lastUpgrade or -99)) < math.max(1, CFG.UpgradeEvery) then return end
    S.lastUpgrade = S.loops
    B.upgradeTreadmill()
    B.upgradePen()
end

--=====================================================================
--  TREADMILL  (ยืนบนลู่เพื่อปั้ม Speed)
--=====================================================================
local function speedStat()
    local ls = LP:FindFirstChild("leaderstats")
    local sp = ls and ls:FindFirstChild("Speed")
    return sp and (tonumber(sp.Value) or 0) or 0
end

-- โซนถัดไปที่ยังเข้าไม่ได้ ต้องการ WalkSpeed เท่าไหร่
local function nextAreaNeed()
    local mine = U.walkSpeed()
    local best
    for id in pairs(G.Guards) do
        if A.areaAllowed(id) then
            local need = guardSpeed(id)
            if need > mine and (not best or need < best) then best = need end
        end
    end
    return best
end

local function rideTreadmill(seconds)
    if not S.tread then return end
    S.status = "treadmill"
    local pos = S.tread.Position + Vector3.new(0, 4, 0)
    M.goTo(pos, 5)
    local t0 = os.clock()
    while S.alive and os.clock() - t0 < seconds do
        local _, hrp = U.char()
        if hrp and (hrp.Position - pos).Magnitude > 8 then M.goTo(pos, 4) end
        task.wait(0.5)
    end
    S.lastTread = S.loops
end

-- บัญชีใหม่ WalkSpeed 16 = เท่ากับ guard Forest เป๊ะๆ -> วิ่งหนีไม่ทัน โดนจับตาย
-- ต้องปั้ม Speed ให้เร็วกว่า guard โซนแรกก่อน ค่อยออกไปขโมย
-- (WalkSpeed โตช้ามากเทียบกับ stat Speed ~ Speed^0.165 แต่ช่วงแรกขึ้นเร็ว
--  Speed 10 -> walk 16, Speed ~23 -> walk ~18 ใช้เวลาบนลู่แค่ไม่กี่วิ)
local function tooSlowToSteal()
    if not CFG.RespectGuardSpeed then return false end
    return U.walkSpeed() < A.easiestGuard() * CFG.MinSpeedToSteal
end

local function treadmillIfNeeded()
    if not CFG.RideTreadmill or not S.tread then return end
    local target = U.parseAmount(CFG.SpeedTarget)
    if target > 0 and speedStat() >= target then return end

    local need = nextAreaNeed()
    local due = CFG.TreadmillEvery > 0 and (S.loops - S.lastTread) >= CFG.TreadmillEvery
    if need or due then
        rideTreadmill(CFG.TreadmillSeconds)
    end
end

--=====================================================================
--  EVENT WIRING  (สถานะแบกไข่ / รอบรีเซ็ตโซน)
--=====================================================================
local function wireEvents()
    local net = ReplicatedStorage:FindFirstChild("Network")
    if not net then return end

    local carry = net:FindFirstChild("Eggs: AreaEggCarryState")
    if carry then
        track(carry.OnClientEvent:Connect(function(state)
            if type(state) == "table" and state.IsCarrying then
                S.carrying = state
                S.carryMul = state.SpeedMultiplier or 1
            else
                S.carrying = nil
                S.carryMul = 1
            end
        end))
    end

    local removed = net:FindFirstChild("Eggs: AreaEggRemoved")
    if removed then
        track(removed.OnClientEvent:Connect(function()
            promptCache.at = 0
        end))
    end

    local countdown = net:FindFirstChild("Eggs: AreaEggResetStartCountdown")
    if countdown then
        track(countdown.OnClientEvent:Connect(function(info)
            if not CFG.HandleReset then return end
            local secs = 3
            if type(info) == "table" then
                secs = tonumber(info.Seconds or info.Duration or info.Countdown) or 3
            elseif type(info) == "number" then
                secs = info
            end
            S.resetting = true
            S.resetUntil = os.clock() + secs + CFG.ResetHoldFor
            log("area reset incoming - retreating home")
        end))
    end

    -- ตัวละครเกิดใหม่ -> รีเซ็ตสถานะการแบก
    track(LP.CharacterAdded:Connect(function()
        S.carrying = nil
        S.carryMul = 1
        task.wait(1.5)
        pcall(resolvePlot)
    end))
end

-- ระหว่างโซนรีเซ็ต: กลับฐาน แล้วรอจนไข่เกิดใหม่
local function handleReset()
    if not S.resetting then return false end
    S.status = "area reset - holding"
    M.goHome()
    while S.alive and os.clock() < S.resetUntil do task.wait(0.5) end

    -- รอจนกว่าจะมีไข่สถานะ Slot กลับมา
    local t0 = os.clock()
    while S.alive and os.clock() - t0 < CFG.ResetWaitMax do
        local n = 0
        for _, rec in pairs(A.snapshot()) do
            if rec.State == "Slot" then n = n + 1 end
        end
        if n >= 5 then break end
        task.wait(2)
    end
    S.resetting = false
    promptCache.at = 0
    log("area reset done - resuming")
    return true
end

--=====================================================================
--  UI  (แผงสถานะมุมจอ)
--=====================================================================
local function buildUI()
    if not CFG.ShowUI then return end
    -- ล้างแผงเก่าทิ้งก่อน กัน GUI ซ้อนกันตอนรันสคริปต์ซ้ำ
    pcall(function()
        for _, g in ipairs(game:GetService("CoreGui"):GetChildren()) do
            if g.Name == "EggFarmStatus" then g:Destroy() end
        end
    end)
    pcall(function()
        local pg = LP:FindFirstChild("PlayerGui")
        if pg then
            for _, g in ipairs(pg:GetChildren()) do
                if g.Name == "EggFarmStatus" then g:Destroy() end
            end
        end
    end)

    local gui = Instance.new("ScreenGui")
    gui.Name = "EggFarmStatus"
    gui.ResetOnSpawn = false
    gui.IgnoreGuiInset = true
    gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    pcall(function() gui.Parent = game:GetService("CoreGui") end)
    if not gui.Parent then gui.Parent = LP:WaitForChild("PlayerGui") end

    -- วางกลางจอ (ขยับได้ด้วย CFG.UIPosX / UIPosY  0.5 = กลาง)
    local frame = Instance.new("Frame")
    frame.Size = UDim2.new(0, 300, 0, CFG.UIButtons and 194 or 158)
    frame.AnchorPoint = Vector2.new(0.5, 0.5)
    frame.Position = UDim2.new(CFG.UIPosX or 0.5, 0, CFG.UIPosY or 0.5, 0)
    frame.BackgroundColor3 = Color3.fromRGB(16, 16, 22)
    frame.BackgroundTransparency = 0.25
    frame.BorderSizePixel = 0
    frame.Parent = gui
    Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 8)

    local label = Instance.new("TextLabel")
    label.Size = UDim2.new(1, -16, 1, CFG.UIButtons and -50 or -16)
    label.Position = UDim2.new(0, 8, 0, 8)
    label.BackgroundTransparency = 1
    label.Font = Enum.Font.Code
    label.TextSize = CFG.StatusTextSize
    label.TextColor3 = Color3.fromRGB(235, 235, 245)
    label.TextXAlignment = Enum.TextXAlignment.Center
    label.TextYAlignment = Enum.TextYAlignment.Center
    label.Text = "Egg Farm starting..."
    label.Parent = frame

    -- ===== ปุ่มกด: กดรันได้เลย ไม่ต้องพิมพ์คำสั่งใน console =====
    local btnPause, btnMode
    if CFG.UIButtons then
        local row = Instance.new("Frame")
        row.Size = UDim2.new(1, -16, 0, 30)
        row.Position = UDim2.new(0, 8, 1, -38)
        row.BackgroundTransparency = 1
        row.Parent = frame

        local layout = Instance.new("UIListLayout")
        layout.FillDirection = Enum.FillDirection.Horizontal
        layout.Padding = UDim.new(0, 6)
        layout.Parent = row

        local function mkBtn(text, w, color, fn)
            local b = Instance.new("TextButton")
            b.Size = UDim2.new(w, -4, 1, 0)
            b.BackgroundColor3 = color
            b.BorderSizePixel = 0
            b.AutoButtonColor = true
            b.Font = Enum.Font.GothamBold
            b.TextSize = 13
            b.TextColor3 = Color3.fromRGB(245, 245, 250)
            b.Text = text
            b.Parent = row
            Instance.new("UICorner", b).CornerRadius = UDim.new(0, 6)
            track(b.MouseButton1Click:Connect(function() pcall(fn, b) end))
            return b
        end

        btnPause = mkBtn(S.paused and "START" or "PAUSE", 0.34, Color3.fromRGB(38, 110, 62), function(b)
            S.paused = not S.paused
            b.Text = S.paused and "START" or "PAUSE"
            b.BackgroundColor3 = S.paused and Color3.fromRGB(38, 110, 62) or Color3.fromRGB(126, 96, 24)
            log(S.paused and "paused" or "resumed")
        end)

        btnMode = mkBtn("MODE: " .. tostring(CFG.MoveMode), 0.42, Color3.fromRGB(40, 62, 120), function(b)
            local order = { "humtween", "walk", "tween" }
            local i = 1
            for n, m in ipairs(order) do if m == CFG.MoveMode then i = n break end end
            CFG.MoveMode = order[(i % #order) + 1]
            pcall(function() M.humRestore() end)
            b.Text = "MODE: " .. CFG.MoveMode
            log("move mode ->", CFG.MoveMode)
        end)

        mkBtn("STOP", 0.24, Color3.fromRGB(130, 40, 44), function()
            _G.EggStop()
        end)
    end

    -- ===== ลากแผงย้ายที่ =====
    if CFG.UIDraggable then
        local UIS = game:GetService("UserInputService")
        local dragging, dragStart, startPos
        track(frame.InputBegan:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1
                or input.UserInputType == Enum.UserInputType.Touch then
                dragging, dragStart, startPos = true, input.Position, frame.Position
            end
        end))
        track(UIS.InputChanged:Connect(function(input)
            if not dragging then return end
            if input.UserInputType ~= Enum.UserInputType.MouseMovement
                and input.UserInputType ~= Enum.UserInputType.Touch then return end
            local d = input.Position - dragStart
            frame.Position = UDim2.new(
                startPos.X.Scale, startPos.X.Offset + d.X,
                startPos.Y.Scale, startPos.Y.Offset + d.Y)
        end))
        track(UIS.InputEnded:Connect(function(input)
            if input.UserInputType == Enum.UserInputType.MouseButton1
                or input.UserInputType == Enum.UserInputType.Touch then
                dragging = false
            end
        end))
    end

    S.ui = { gui = gui, frame = frame, label = label, btnPause = btnPause, btnMode = btnMode }
end

local function updateUI()
    if not S.ui then return end
    local mins = (os.clock() - S.startClock) / 60
    local ls = LP:FindFirstChild("leaderstats")
    local mps = ls and ls:FindFirstChild("Money/s")
    S.ui.label.Text = table.concat({
        (S.paused and "[PAUSED] " or "[RUN] ") .. S.status,
        string.format("stolen %d   hatched %d   sold %d", S.stolen, S.hatched, S.sold),
        string.format("placed %d   failed %d   upg %d", S.placed, S.failed, S.upgrades),
        string.format("speed %s   walk %.0f", U.short(speedStat()), U.walkSpeed()),
        string.format("$/s %s   cash %s",
            U.short(U.parseAmount(tostring(mps and mps.Value or 0):gsub("%$", ""))), U.short(B.cash())),
        string.format("mode %s%s   uptime %.1f min",
            tostring(CFG.MoveMode), S.humLocked and "*" or "", mins),
        "F2 pause  F3 mode  F4 hide",
    }, "\n")

    -- ปุ่มอาจโดนสั่งจาก hotkey/โค้ดอื่น ต้องซิงก์ข้อความให้ตรงสถานะจริง
    if S.ui.btnPause then
        S.ui.btnPause.Text = S.paused and "START" or "PAUSE"
        S.ui.btnPause.BackgroundColor3 = S.paused
            and Color3.fromRGB(38, 110, 62) or Color3.fromRGB(126, 96, 24)
    end
    if S.ui.btnMode then S.ui.btnMode.Text = "MODE: " .. tostring(CFG.MoveMode) end
end

--=====================================================================
--  QoL  (anti-afk / perf / hotkey)
--=====================================================================
-- Anti-kick: ดัก :Kick() ที่ยิงจากฝั่ง client เท่านั้น
-- **หยุด kick ฝั่งเซิร์ฟเวอร์ (เช่น BAC-2513 / Error 267) ไม่ได้**
-- ทางแก้จริงคือ MoveMode = "walk" เพื่อไม่ให้เซิร์ฟจับได้ตั้งแต่แรก
local function installAntiKick()
    if not CFG.AntiKick then return end
    local g = getgenv()
    if g.__egg_antikick then return end
    local ok = pcall(function()
        local mt = getrawmetatable(game)
        local old = mt.__namecall
        setreadonly(mt, false)
        mt.__namecall = newcclosure(function(self, ...)
            local m = getnamecallmethod()
            if m == "Kick" and typeof(self) == "Instance" and self:IsA("Player") then
                warn("[Egg] blocked client-side Kick: " .. tostring((...)):sub(1, 60))
                return nil
            end
            return old(self, ...)
        end)
        setreadonly(mt, true)
    end)
    g.__egg_antikick = ok
    log("anti-kick", ok and "installed (client-side only)" or "FAILED")
end

local function setupQoL()
    installAntiKick()

    if CFG.AntiAFK then
        local ok, vu = pcall(function() return game:GetService("VirtualUser") end)
        if ok and vu then
            track(LP.Idled:Connect(function()
                pcall(function()
                    vu:CaptureController()
                    vu:ClickButton2(Vector2.new(0, 0))
                end)
            end))
        end
    end

    if CFG.FpsBoost then pcall(function() setfpscap(CFG.FpsCap) end) end

    if CFG.PerfMode then
        pcall(function()
            settings().Rendering.QualityLevel = Enum.QualityLevel.Level01
            Lighting.GlobalShadows = false
            Lighting.FogEnd = 1e6
            for _, d in ipairs(Lighting:GetChildren()) do
                if d:IsA("PostEffect") then d.Enabled = false end
            end
        end)
    end

    local UIS = game:GetService("UserInputService")
    track(UIS.InputBegan:Connect(function(input, gpe)
        if gpe then return end
        if input.KeyCode == Enum.KeyCode.F2 then
            S.paused = not S.paused
            log(S.paused and "paused" or "resumed")
        elseif input.KeyCode == Enum.KeyCode.F3 then
            _G.EggMode()
        elseif input.KeyCode == Enum.KeyCode.F4 then
            if S.ui and S.ui.frame then S.ui.frame.Visible = not S.ui.frame.Visible end
        end
    end))
end

--=====================================================================
--  SAFETY  (กันตาย - เกมนี้ตายแล้วไม่เกิดใหม่ให้ ต้องออกแล้วเข้าใหม่)
--=====================================================================
local function guardCharacter(char)
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    if not hum then return end
    pcall(function()
        -- ปิดสถานะที่ทำให้เกิดดาเมจตกจากที่สูง
        hum:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
        hum:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
    end)
end

local function isDead()
    local char = LP.Character
    local hum = char and char:FindFirstChildOfClass("Humanoid")
    return hum ~= nil and hum.Health <= 0
end

-- พยายามเกิดใหม่: ยิง remote reset แล้วรอ CharacterAdded
local function reviveIfDead()
    if not isDead() then return true end

    -- ตายตอนใช้ humtween = แรงไป ลดความเร็วลงเอง ไม่ให้ตายซ้ำ
    if CFG.MoveMode == "humtween" then
        pcall(function() M.humRestore() end)
        if (tonumber(CFG.HumTweenSpeed) or 0) > 0 then
            -- ความเร็วคงที่ -> หั่นลงครึ่งหนึ่ง ต่ำกว่า 120 ก็เลิกใช้ค่าคงที่
            CFG.HumTweenSpeed = math.floor(CFG.HumTweenSpeed / 2)
            if CFG.HumTweenSpeed < 120 then CFG.HumTweenSpeed = 0 end
            warn(("[Egg] ตายตอน humtween - ลด HumTweenSpeed เหลือ %d (0 = ผูกกับ WalkSpeed)")
                :format(CFG.HumTweenSpeed))
        elseif (CFG.HumTweenSpeedMul or 2) > 1 then
            CFG.HumTweenSpeedMul = math.max(1, (CFG.HumTweenSpeedMul or 2) - 0.5)
            warn(("[Egg] ตายตอน humtween - ลด HumTweenSpeedMul เหลือ %.1f")
                :format(CFG.HumTweenSpeedMul))
        else
            CFG.MoveMode = M.fallbackMode()
            warn("[Egg] ตายทั้งที่ humtween 1x แล้ว - สลับไปโหมด " .. CFG.MoveMode .. " ถาวร")
        end
    elseif CFG.MoveMode == "tween" then
        if (CFG.TweenSpeedMul or 1) > 1 then
            CFG.TweenSpeedMul = math.max(1, (CFG.TweenSpeedMul or 1) - 0.5)
            warn(("[Egg] ตายตอน tween - ลด TweenSpeedMul เหลือ %.1f"):format(CFG.TweenSpeedMul))
        else
            CFG.MoveMode = "walk"
            warn("[Egg] ตายทั้งที่ tween 1x แล้ว - สลับไปโหมด walk ถาวร")
        end
    end
    pcall(function() M.unlock() end)

    S.status = "dead - trying to respawn"
    warn("[Egg] ตัวละครตาย - กำลังขอเกิดใหม่ (ถ้าไม่เกิดภายใน 30 วิ ให้ออกแล้วเข้าเกมใหม่)")
    -- v447: RE/RigSync/AskRigWipe ไม่ใช่ "ขอเกิดใหม่"
    -- เกมยิงมันจาก Humanoid.Died เป็น "แจ้งว่าตายแล้ว" พร้อมส่ง character Model ไปด้วย
    -- ยิงเองรัวๆ จึงไม่ช่วยให้เกิดใหม่ และเป็นพฤติกรรมที่ผิดปกติให้เซิร์ฟจับ -> ไม่ยิง
    -- เกมนี้ตายแล้วต้องออกแล้วเข้าใหม่อย่างเดียว  ได้แค่รอเผื่อ CharacterAutoLoads ทำงาน
    local t0 = os.clock()
    while S.alive and os.clock() - t0 < 30 do
        task.wait(0.5)
        if not isDead() then
            guardCharacter(LP.Character)
            log("respawned")
            return true
        end
    end
    warn("[Egg] ไม่เกิดใหม่ให้ - ต้องออกแล้วเข้าเกมใหม่เอง")
    return false
end

--=====================================================================
--  MAIN LOOP
--=====================================================================
local function tendBase()
    S.status = "base work"
    M.goHome()
    B.placeEggs()
    B.hatchReady()
    B.equipAndSell()
    B.upgrade()
end

local function cycle()
    S.loops = S.loops + 1

    if handleReset() then return end

    -- 1) ดูก่อนว่ามีไข่ให้เก็บไหม  <<< เก็บไข่มาเป็นอันดับแรก
    local pets = B.myPets()
    local ownedBest = pets[1] and pets[1].mps or 0
    local list = A.candidates(ownedBest)

    -- ไม่มีไข่ในโซนที่เข้าได้เลย
    if #list == 0 then
        -- ถ้าช้าเกินจนเข้าโซนดีๆ ไม่ได้ ค่อยไปปั้ม Speed
        -- (โซนง่ายสุดเข้าได้เสมออยู่แล้ว ถ้าถึงตรงนี้แปลว่าไข่โซนนั้นหมด/ถูกเก็บไป)
        if CFG.CollectFirst and tooSlowToSteal() then
            S.status = string.format("waiting for eggs / too slow (walk %.0f) - train", U.walkSpeed())
        else
            S.status = "no eggs available - waiting"
        end
        tendBase()
        if CFG.RideTreadmill and S.tread and tooSlowToSteal() then
            rideTreadmill(CFG.TreadmillSeconds)
        else
            task.wait(3)
        end
        return
    end

    if CFG.Verbose then
        local top = {}
        for i = 1, math.min(3, #list) do
            top[#top + 1] = string.format("%s %s/s", list[i].rec.AssetCategory, U.short(list[i].value))
        end
        log(("%d eggs worth taking | best: %s"):format(#list, table.concat(top, " > ")))
    end

    -- เก็บทีละฟอง แล้วดูรายการใหม่ทุกครั้ง
    -- (ไข่ในลิสต์เก่าอาจโดนคนอื่นเอาไปแล้ว - จะได้ไม่วิ่งไปเก้อ)
    local grabbed, tried = 0, {}
    while grabbed < math.max(1, CFG.ChainGrab) do
        if not S.alive or S.paused or S.resetting then break end

        local cand
        for _, c in ipairs(list) do
            if not tried[c.rec.Uid] then cand = c break end
        end
        if not cand then break end
        tried[cand.rec.Uid] = true

        if stealEgg(cand) then
            if carryHome() then
                grabbed = grabbed + 1
            else
                log("claim timed out - dropping to base work")
                break
            end
        end

        if grabbed < math.max(1, CFG.ChainGrab) then
            list = A.candidates(ownedBest)
            if #list == 0 then break end
        end
        task.wait(0.1)
    end

    -- 2) งานที่ฐาน
    if grabbed > 0 or (S.loops % math.max(1, CFG.TendEvery) == 0) then
        tendBase()
    end

    -- 3) ปั้ม Speed
    treadmillIfNeeded()

    task.wait(CFG.LoopDelay)
end

--=====================================================================
--  BOOT
--=====================================================================
function _G.EggStop()
    S.alive = false
    _G.__EGG_RUNNING = false
    pcall(function() M.humRestore() end)        -- คืน WalkSpeed จริง ไม่งั้นผู้เล่นเดินไม่ได้
    pcall(function() M.releaseControls() end)   -- คืนการควบคุมให้ผู้เล่น
    pcall(function() M.unlock() end)            -- ห้ามทิ้งตัวไว้แบบ anchored
    for _, c in ipairs(S.conns) do pcall(function() c:Disconnect() end) end
    S.conns = {}
    if S.ui and S.ui.gui then pcall(function() S.ui.gui:Destroy() end) end
    print("[Egg] stopped")
end

function _G.EggPause(v)
    if v == nil then S.paused = not S.paused else S.paused = v and true or false end
    return S.paused
end

-- เริ่ม/เล่นต่อ  (ปุ่ม START บนแผง = เรียกอันนี้)
function _G.EggStart()
    S.paused = false
    return true
end

-- สลับโหมดเดิน  ไม่ใส่อะไร = วนไปตัวถัดไป  ใส่ชื่อ = ตั้งตรงๆ
function _G.EggMode(mode)
    local order = { "humtween", "walk", "tween" }
    if mode then
        local want = tostring(mode):lower()
        -- ชื่อโหมดผิด = ตกไปเป็น humtween เงียบๆ ตาม goTo ซึ่งไม่ใช่สิ่งที่ผู้ใช้ตั้งใจ
        if want ~= "humtween" and want ~= "walk" and want ~= "tween" and want ~= "warp" then
            warn('[Egg] ไม่รู้จักโหมด "' .. want .. '" - ใช้ได้: humtween / walk / tween / warp')
            return CFG.MoveMode
        end
        CFG.MoveMode = want
    else
        local i = 1
        for n, m in ipairs(order) do if m == CFG.MoveMode then i = n break end end
        CFG.MoveMode = order[(i % #order) + 1]
    end
    pcall(function() M.humRestore() end)
    log("move mode ->", CFG.MoveMode)
    return CFG.MoveMode
end

-- แก้ config สดๆ ตอนรันอยู่  เช่น _G.EggSet{ ChainGrab = 8, HumTweenSpeed = 450 }
function _G.EggSet(tbl)
    for k, v in pairs(tbl or {}) do CFG[k] = v end
    return CFG
end

-- ย้ายตัวเองไปจุดที่ต้องการด้วยตัว mover เดียวกับที่ฟาร์มใช้ (ไว้ทดสอบ/ใช้มือ)
function _G.EggGoTo(pos, tol)
    if typeof(pos) == "CFrame" then pos = pos.Position end
    return M.goTo(pos, tol or 5)
end

-- คืนสเตตัสตัวละครทันที (เผื่อสคริปต์ค้างแล้วเดินไม่ได้)
function _G.EggRelease()
    pcall(function() M.humRestore() end)
    pcall(function() M.unlock() end)
    pcall(function() M.releaseControls() end)
    return true
end

local function boot()
    repeat task.wait() until game:IsLoaded()
    task.wait(1)

    buildUI()
    setupQoL()
    wireEvents()

    guardCharacter(LP.Character)
    track(LP.CharacterAdded:Connect(function(c)
        task.wait(0.5)
        guardCharacter(c)
    end))

    -- รอ plot ของตัวเองให้เจอ (หลังย้ายเซิร์ฟจะเปลี่ยนเลข slot)
    local t0 = os.clock()
    while S.alive and not resolvePlot() and os.clock() - t0 < 45 do
        S.status = "waiting for plot"
        updateUI()
        task.wait(1)
    end
    if not S.plot then
        warn("[Egg] หา plot ของตัวเองไม่เจอ - หยุดทำงาน")
        _G.EggStop()
        return
    end
    log("plot", S.plot.Name, "| pen", tostring(S.pen and S.pen.Position))

    B.claimOffline()

    -- เก็บกวาดของค้างจากเซสชันก่อน
    tendBase()

    -- ต่ออายุตัวเองหลังโดนย้ายเซิร์ฟ
    if CFG.SurviveTeleport and CFG.SourceUrl then
        pcall(function()
            queue_on_teleport(([[
                _G.EggConfig = game:GetService("HttpService"):JSONDecode(%q)
                loadstring(game:HttpGet(%q))()
            ]]):format(game:GetService("HttpService"):JSONEncode({
                Area = CFG.Area, ChainGrab = CFG.ChainGrab, KeepAbove = tostring(CFG.KeepAbove),
                MinEggRate = tostring(CFG.MinEggRate), AutoSell = CFG.AutoSell, AutoHatch = CFG.AutoHatch,
            }), CFG.SourceUrl))
        end)
    end

    -- ลูป UI
    spawnLoop(function()
        updateUI()
        task.wait(0.35)
    end)

    -- สแกนแบบอ่านอย่างเดียวเป็นระยะ และเก็บคะแนนไว้เพื่อเทียบกับเซิร์ฟที่ผู้ใช้เข้าเอง
    spawnLoop(function()
        if not S.paused then
            pcall(function() EggScanner.Scan() end)
        end
        task.wait(math.max(15, tonumber(CFG.LoopDelay) or 15))
    end)

    -- ลูปหลัก
    spawnLoop(function()
        if S.paused then
            S.status = "paused"
            task.wait(0.5)
            return
        end
        if isDead() then
            if not reviveIfDead() then
                S.status = "dead - rejoin needed"
                task.wait(5)
            end
            return
        end
        if not U.char() then
            S.status = "waiting for character"
            task.wait(1)
            return
        end
        if not S.plot or not S.plot.Parent then
            resolvePlot()
            task.wait(1)
            return
        end
        cycle()
    end)

    log(("started | preset %s | mode %s | F2 pause  F3 mode  F4 hide")
        :format(tostring(CFG.Preset), tostring(CFG.MoveMode)))
    log("commands: _G.EggStart() _G.EggPause() _G.EggMode() _G.EggSet{} _G.EggRelease() _G.EggStop()")
end

task.spawn(boot)